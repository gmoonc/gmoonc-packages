-- Criar a função update_profile_name
CREATE OR REPLACE FUNCTION update_profile_name(user_id UUID, new_name TEXT)
RETURNS VOID AS $$
BEGIN
    UPDATE profiles
    SET
        name = new_name,
        updated_at = NOW()
    WHERE id = user_id;
    
    -- Log para debug
    RAISE NOTICE 'Nome atualizado para % no perfil %', new_name, user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Conceder permissões para usuários autenticados
GRANT EXECUTE ON FUNCTION update_profile_name(UUID, TEXT) TO authenticated;;
