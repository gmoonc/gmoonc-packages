-- Função para sincronizar email na tabela profiles
CREATE OR REPLACE FUNCTION sync_profile_email(user_id UUID, new_email TEXT)
RETURNS VOID AS $$
BEGIN
  UPDATE profiles 
  SET 
    email = new_email,
    updated_at = NOW()
  WHERE id = user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
-- Conceder permissões para usuários autenticados
GRANT EXECUTE ON FUNCTION sync_profile_email(UUID, TEXT) TO authenticated;
