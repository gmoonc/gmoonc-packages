-- Função para atualizar o perfil quando o usuário é atualizado no auth.users
CREATE OR REPLACE FUNCTION public.update_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = ''
AS $$
BEGIN
  -- Log para debug
  RAISE NOTICE 'Trigger update_user executado para usuário %', new.id;
  RAISE NOTICE 'Email anterior: %, Email novo: %', old.email, new.email;
  
  -- Atualizar o perfil na tabela profiles
  UPDATE public.profiles
  SET 
    email = new.email,
    updated_at = NOW()
  WHERE id = new.id;
  
  -- Log de sucesso
  RAISE NOTICE 'Perfil atualizado com sucesso para usuário %', new.id;
  
  RETURN new;
END;
$$;;
