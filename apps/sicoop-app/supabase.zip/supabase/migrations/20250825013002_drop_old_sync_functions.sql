-- Remover as funções antigas que não funcionavam
DROP FUNCTION IF EXISTS public.sync_profile_email(UUID, TEXT);
DROP FUNCTION IF EXISTS public.sync_profile_email_admin(UUID, TEXT);;
