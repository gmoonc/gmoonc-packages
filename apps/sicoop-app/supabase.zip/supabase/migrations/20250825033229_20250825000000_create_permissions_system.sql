-- Migration: 20250825000000_create_permissions_system.sql
-- Description: Sistema de permissões para o Sicoop
-- Date: 2025-08-25

-- 1. Criar tabela de roles (papéis/funções)
CREATE TABLE IF NOT EXISTS public.roles (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    is_system_role BOOLEAN DEFAULT false, -- Roles do sistema não podem ser deletadas
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Criar tabela de módulos (áreas do sistema)
CREATE TABLE IF NOT EXISTS public.modules (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Criar tabela de permissões (relacionamento entre roles e módulos)
CREATE TABLE IF NOT EXISTS public.permissions (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    role_id UUID NOT NULL REFERENCES public.roles(id) ON DELETE CASCADE,
    module_id UUID NOT NULL REFERENCES public.modules(id) ON DELETE CASCADE,
    can_access BOOLEAN DEFAULT false,
    can_create BOOLEAN DEFAULT false,
    can_read BOOLEAN DEFAULT false,
    can_update BOOLEAN DEFAULT false,
    can_delete BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(role_id, module_id)
);

-- 4. Inserir roles padrão do sistema
INSERT INTO public.roles (name, description, is_system_role) VALUES
    ('administrador', 'Administrador do sistema com acesso total', true),
    ('funcionario', 'Funcionário com acesso limitado', true),
    ('cliente', 'Cliente com acesso básico', true)
ON CONFLICT (name) DO NOTHING;

-- 5. Inserir módulos padrão do sistema
INSERT INTO public.modules (name, display_name, description) VALUES
    ('administrativo', 'Administrativo', 'Módulo administrativo do sistema'),
    ('financeiro', 'Financeiro', 'Módulo financeiro do sistema'),
    ('helpdesk', 'Help-Desk', 'Módulo de suporte técnico'),
    ('secretaria', 'Secretaria', 'Módulo de secretaria'),
    ('tecnico', 'Técnico', 'Módulo técnico'),
    ('vendas', 'Vendas', 'Módulo de vendas'),
    ('cliente', 'Cliente', 'Módulo de cliente')
ON CONFLICT (name) DO NOTHING;

-- 6. Inserir permissões padrão
-- Administrador tem acesso total a todos os módulos
INSERT INTO public.permissions (role_id, module_id, can_access, can_create, can_read, can_update, can_delete)
SELECT 
    r.id as role_id,
    m.id as module_id,
    true, true, true, true, true
FROM public.roles r
CROSS JOIN public.modules m
WHERE r.name = 'administrador'
ON CONFLICT (role_id, module_id) DO NOTHING;

-- Funcionário tem acesso limitado
INSERT INTO public.permissions (role_id, module_id, can_access, can_create, can_read, can_update, can_delete)
SELECT 
    r.id as role_id,
    m.id as module_id,
    true, true, true, true, false
FROM public.roles r
CROSS JOIN public.modules m
WHERE r.name = 'funcionario' AND m.name != 'administrativo'
ON CONFLICT (role_id, module_id) DO NOTHING;

-- Cliente tem acesso básico apenas ao módulo cliente
INSERT INTO public.permissions (role_id, module_id, can_access, can_create, can_read, can_update, can_delete)
SELECT 
    r.id as role_id,
    m.id as module_id,
    true, false, true, false, false
FROM public.roles r
CROSS JOIN public.modules m
WHERE r.name = 'cliente' AND m.name = 'cliente'
ON CONFLICT (role_id, module_id) DO NOTHING;

-- 7. Habilitar RLS
ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.modules ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.permissions ENABLE ROW LEVEL SECURITY;

-- 8. Políticas de segurança para roles
-- Todos podem ver roles
CREATE POLICY "Anyone can view roles" ON public.roles
    FOR SELECT USING (true);

-- Apenas administradores podem criar/atualizar/deletar roles
CREATE POLICY "Only admins can manage roles" ON public.roles
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 9. Políticas de segurança para módulos
-- Todos podem ver módulos
CREATE POLICY "Anyone can view modules" ON public.modules
    FOR SELECT USING (true);

-- Apenas administradores podem gerenciar módulos
CREATE POLICY "Only admins can manage modules" ON public.modules
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 10. Políticas de segurança para permissões
-- Usuários podem ver permissões relacionadas ao seu role
CREATE POLICY "Users can view permissions for their role" ON public.permissions
    FOR SELECT USING (
        role_id IN (
            SELECT id FROM public.roles 
            WHERE name = (SELECT role FROM public.profiles WHERE id = auth.uid())
        )
    );

-- Apenas administradores podem gerenciar permissões
CREATE POLICY "Only admins can manage permissions" ON public.permissions
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 11. Criar função para verificar permissões
CREATE OR REPLACE FUNCTION public.check_permission(
    user_id UUID,
    module_name TEXT,
    permission_type TEXT DEFAULT 'access'
)
RETURNS BOOLEAN AS $$
DECLARE
    user_role TEXT;
    has_permission BOOLEAN;
BEGIN
    -- Buscar role do usuário
    SELECT role INTO user_role
    FROM public.profiles
    WHERE id = user_id;
    
    -- Se não encontrou usuário, negar acesso
    IF user_role IS NULL THEN
        RETURN false;
    END IF;
    
    -- Se for administrador, sempre permitir
    IF user_role = 'administrador' THEN
        RETURN true;
    END IF;
    
    -- Verificar permissão específica
    SELECT 
        CASE 
            WHEN permission_type = 'access' THEN can_access
            WHEN permission_type = 'create' THEN can_create
            WHEN permission_type = 'read' THEN can_read
            WHEN permission_type = 'update' THEN can_update
            WHEN permission_type = 'delete' THEN can_delete
            ELSE can_access
        END INTO has_permission
    FROM public.permissions p
    JOIN public.roles r ON p.role_id = r.id
    JOIN public.modules m ON p.module_id = m.id
    WHERE r.name = user_role AND m.name = module_name;
    
    RETURN COALESCE(has_permission, false);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 12. Criar função para obter permissões do usuário
CREATE OR REPLACE FUNCTION public.get_user_permissions(user_id UUID)
RETURNS TABLE(
    module_name TEXT,
    module_display_name TEXT,
    can_access BOOLEAN,
    can_create BOOLEAN,
    can_read BOOLEAN,
    can_update BOOLEAN,
    can_delete BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        m.name,
        m.display_name,
        p.can_access,
        p.can_create,
        p.can_read,
        p.can_update,
        p.can_delete
    FROM public.permissions p
    JOIN public.roles r ON p.role_id = r.id
    JOIN public.modules m ON p.module_id = m.id
    JOIN public.profiles prof ON prof.role = r.name
    WHERE prof.id = user_id AND m.is_active = true
    ORDER BY m.name;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 13. Criar triggers para atualizar timestamps
CREATE TRIGGER update_roles_updated_at 
    BEFORE UPDATE ON public.roles 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_modules_updated_at 
    BEFORE UPDATE ON public.modules 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_permissions_updated_at 
    BEFORE UPDATE ON public.permissions 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 14. Comentários
COMMENT ON TABLE public.roles IS 'Papéis/funções dos usuários no sistema';
COMMENT ON TABLE public.modules IS 'Módulos/áreas do sistema';
COMMENT ON TABLE public.permissions IS 'Permissões de acesso dos roles aos módulos';
COMMENT ON FUNCTION public.check_permission IS 'Verifica se um usuário tem permissão para um módulo';
COMMENT ON FUNCTION public.get_user_permissions IS 'Retorna todas as permissões de um usuário';;
