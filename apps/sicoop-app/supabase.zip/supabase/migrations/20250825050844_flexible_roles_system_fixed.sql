-- Migração para tornar o sistema de roles flexível (versão corrigida)
-- Permite criar e gerenciar roles dinamicamente

-- 1. Remover a constraint fixa da tabela profiles
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_role_check;

-- 2. Criar função para validar roles antes de inserir/atualizar
CREATE OR REPLACE FUNCTION validate_role_exists()
RETURNS TRIGGER AS $$
BEGIN
    -- Verificar se a role existe na tabela roles
    IF NOT EXISTS (SELECT 1 FROM public.roles WHERE name = NEW.role) THEN
        RAISE EXCEPTION 'Role "%" não existe na tabela roles', NEW.role;
    END IF;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 3. Criar trigger para validação de roles
DROP TRIGGER IF EXISTS trigger_validate_role_exists ON public.profiles;
CREATE TRIGGER trigger_validate_role_exists
    BEFORE INSERT OR UPDATE ON public.profiles
    FOR EACH ROW
    EXECUTE FUNCTION validate_role_exists();

-- 4. Criar função para sincronizar roles automaticamente
CREATE OR REPLACE FUNCTION sync_roles_to_profiles()
RETURNS TRIGGER AS $$
BEGIN
    -- Se uma role foi deletada, atualizar usuários para uma role padrão
    IF TG_OP = 'DELETE' THEN
        UPDATE public.profiles 
        SET role = 'cliente', updated_at = NOW()
        WHERE role = OLD.name;
        RETURN OLD;
    END IF;
    
    -- Se uma role foi inserida ou atualizada, não há ação necessária
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 5. Criar trigger para sincronização automática
DROP TRIGGER IF EXISTS trigger_sync_roles_to_profiles ON public.roles;
CREATE TRIGGER trigger_sync_roles_to_profiles
    AFTER DELETE OR UPDATE ON public.roles
    FOR EACH ROW
    EXECUTE FUNCTION sync_roles_to_profiles();

-- 6. Função para validar se uma role pode ser deletada
CREATE OR REPLACE FUNCTION can_delete_role(role_name TEXT)
RETURNS BOOLEAN AS $$
DECLARE
    user_count INTEGER;
BEGIN
    -- Verificar quantos usuários têm esta role
    SELECT COUNT(*) INTO user_count
    FROM public.profiles
    WHERE role = role_name;
    
    -- Retornar true se não há usuários com esta role
    RETURN user_count = 0;
END;
$$ LANGUAGE plpgsql;

-- 7. Função para obter estatísticas de uso de roles
CREATE OR REPLACE FUNCTION get_role_usage_stats()
RETURNS TABLE (
    role_name TEXT,
    user_count BIGINT,
    can_delete BOOLEAN
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        r.name as role_name,
        COUNT(p.id) as user_count,
        COUNT(p.id) = 0 as can_delete
    FROM public.roles r
    LEFT JOIN public.profiles p ON r.name = p.role
    GROUP BY r.name, r.id
    ORDER BY r.name;
END;
$$ LANGUAGE plpgsql;

-- 8. Comentários para documentação
COMMENT ON FUNCTION validate_role_exists() IS 'Valida se uma role existe antes de inserir/atualizar em profiles';
COMMENT ON FUNCTION sync_roles_to_profiles() IS 'Sincroniza automaticamente as mudanças de roles com a tabela profiles';
COMMENT ON FUNCTION can_delete_role(TEXT) IS 'Verifica se uma role pode ser deletada (sem usuários associados)';
COMMENT ON FUNCTION get_role_usage_stats() IS 'Retorna estatísticas de uso de cada role';;
