-- Migration: 20250825000002_create_analises_cobertura.sql
-- Description: Criação do sistema de análises de cobertura para clientes
-- Date: 2025-08-25

-- 1. Criar tabela de análises de cobertura
CREATE TABLE IF NOT EXISTS public.analises_cobertura (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    telefone TEXT,
    nome_fazenda TEXT NOT NULL,
    area_fazenda_ha DECIMAL(10,2),
    latitude DECIMAL(10,8),
    longitude DECIMAL(10,8),
    observacoes TEXT,
    status TEXT CHECK (status IN ('rascunho', 'enviada', 'em_analise', 'concluida', 'cancelada')) DEFAULT 'rascunho',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Habilitar RLS (Row Level Security)
ALTER TABLE public.analises_cobertura ENABLE ROW LEVEL SECURITY;

-- 3. Criar políticas de segurança
-- Usuários podem ver apenas suas próprias análises
CREATE POLICY "Users can view own analyses" ON public.analises_cobertura
    FOR SELECT USING (auth.uid() = user_id);

-- Usuários podem inserir suas próprias análises
CREATE POLICY "Users can insert own analyses" ON public.analises_cobertura
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Usuários podem atualizar suas próprias análises
CREATE POLICY "Users can update own analyses" ON public.analises_cobertura
    FOR UPDATE USING (auth.uid() = user_id);

-- Usuários podem deletar suas próprias análises
CREATE POLICY "Users can delete own analyses" ON public.analises_cobertura
    FOR DELETE USING (auth.uid() = user_id);

-- Administradores podem ver todas as análises
CREATE POLICY "Admins can view all analyses" ON public.analises_cobertura
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Administradores podem atualizar todas as análises
CREATE POLICY "Admins can update all analyses" ON public.analises_cobertura
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Administradores podem deletar todas as análises
CREATE POLICY "Admins can delete all analyses" ON public.analises_cobertura
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 4. Criar trigger para atualizar timestamp automaticamente
CREATE TRIGGER update_analises_cobertura_updated_at 
    BEFORE UPDATE ON public.analises_cobertura 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- 5. Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_analises_cobertura_user_id ON public.analises_cobertura(user_id);
CREATE INDEX IF NOT EXISTS idx_analises_cobertura_status ON public.analises_cobertura(status);
CREATE INDEX IF NOT EXISTS idx_analises_cobertura_created_at ON public.analises_cobertura(created_at);

-- 6. Comentários da tabela
COMMENT ON TABLE public.analises_cobertura IS 'Análises de cobertura de solo para clientes do Sicoop';
COMMENT ON COLUMN public.analises_cobertura.id IS 'ID único da análise';
COMMENT ON COLUMN public.analises_cobertura.user_id IS 'ID do usuário que criou a análise';
COMMENT ON COLUMN public.analises_cobertura.nome IS 'Nome completo do cliente';
COMMENT ON COLUMN public.analises_cobertura.email IS 'E-mail do cliente';
COMMENT ON COLUMN public.analises_cobertura.telefone IS 'Telefone do cliente';
COMMENT ON COLUMN public.analises_cobertura.nome_fazenda IS 'Nome da propriedade/fazenda';
COMMENT ON COLUMN public.analises_cobertura.area_fazenda_ha IS 'Área da fazenda em hectares';
COMMENT ON COLUMN public.analises_cobertura.latitude IS 'Latitude da propriedade';
COMMENT ON COLUMN public.analises_cobertura.longitude IS 'Longitude da propriedade';
COMMENT ON COLUMN public.analises_cobertura.observacoes IS 'Observações adicionais';
COMMENT ON COLUMN public.analises_cobertura.status IS 'Status atual da análise';
COMMENT ON COLUMN public.analises_cobertura.created_at IS 'Data de criação da análise';
COMMENT ON COLUMN public.analises_cobertura.updated_at IS 'Data da última atualização da análise';;
