-- Migration: 20250825000003_update_status_default.sql
-- Description: Alterar valor padrão do campo status de 'rascunho' para 'solicitada'
-- Date: 2025-08-25

-- 1. Primeiro remover a constraint atual
ALTER TABLE public.analises_cobertura 
DROP CONSTRAINT IF EXISTS analises_cobertura_status_check;

-- 2. Adicionar nova constraint que inclui 'solicitada'
ALTER TABLE public.analises_cobertura 
ADD CONSTRAINT analises_cobertura_status_check 
CHECK (status IN ('rascunho', 'solicitada', 'enviada', 'em_analise', 'concluida', 'cancelada'));

-- 3. Atualizar registros existentes que tenham status 'rascunho' para 'solicitada'
UPDATE public.analises_cobertura 
SET status = 'solicitada' 
WHERE status = 'rascunho';

-- 4. Alterar o valor padrão do campo status
ALTER TABLE public.analises_cobertura 
ALTER COLUMN status SET DEFAULT 'solicitada';

-- 5. Comentário da migração
COMMENT ON COLUMN public.analises_cobertura.status IS 'Status atual da análise (padrão: solicitada)';;
