-- Criar uma versão da função sync_profile_email que funciona com contexto de administrador
CREATE OR REPLACE FUNCTION sync_profile_email_admin(user_id UUID, new_email TEXT)
RETURNS VOID AS $$
BEGIN
    -- Log para debug
    RAISE NOTICE 'Iniciando sincronização de email para usuário % com email %', user_id, new_email;
    
    -- Verificar se o usuário existe
    IF NOT EXISTS (SELECT 1 FROM profiles WHERE id = user_id) THEN
        RAISE EXCEPTION 'Usuário % não encontrado na tabela profiles', user_id;
    END IF;
    
    -- Atualizar o email
    UPDATE profiles
    SET
        email = new_email,
        updated_at = NOW()
    WHERE id = user_id;
    
    -- Verificar se a atualização foi bem-sucedida
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Falha ao atualizar email para usuário %', user_id;
    END IF;
    
    -- Log de sucesso
    RAISE NOTICE 'Email atualizado com sucesso para % no perfil %', new_email, user_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Conceder permissões para usuários autenticados
GRANT EXECUTE ON FUNCTION sync_profile_email_admin(UUID, TEXT) TO authenticated;;
