-- Migration: 20250825000004_create_mensagens.sql
-- Description: Criação do sistema de mensagens para clientes
-- Date: 2025-08-25

-- 1. Criar tabela de mensagens
CREATE TABLE IF NOT EXISTS public.mensagens (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    nome TEXT NOT NULL,
    email TEXT NOT NULL,
    telefone TEXT,
    empresa_fazenda TEXT NOT NULL,
    mensagem TEXT NOT NULL,
    status TEXT CHECK (status IN ('rascunho', 'enviada', 'em_analise', 'respondida', 'fechada')) DEFAULT 'enviada',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Habilitar RLS (Row Level Security)
ALTER TABLE public.mensagens ENABLE ROW LEVEL SECURITY;

-- 3. Criar políticas de segurança
-- Usuários podem ver apenas suas próprias mensagens
CREATE POLICY "Users can view own messages" ON public.mensagens
    FOR SELECT USING (auth.uid() = user_id);

-- Usuários podem inserir suas próprias mensagens
CREATE POLICY "Users can insert own messages" ON public.mensagens
    FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Usuários podem atualizar suas próprias mensagens
CREATE POLICY "Users can update own messages" ON public.mensagens
    FOR UPDATE USING (auth.uid() = user_id);

-- Usuários podem deletar suas próprias mensagens
CREATE POLICY "Users can delete own messages" ON public.mensagens
    FOR DELETE USING (auth.uid() = user_id);

-- Administradores podem ver todas as mensagens
CREATE POLICY "Admins can view all messages" ON public.mensagens
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Administradores podem atualizar todas as mensagens
CREATE POLICY "Admins can update all messages" ON public.mensagens
    FOR UPDATE USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Administradores podem deletar todas as mensagens
CREATE POLICY "Admins can delete all messages" ON public.mensagens
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 4. Criar trigger para atualizar timestamp automaticamente
CREATE TRIGGER update_mensagens_updated_at 
    BEFORE UPDATE ON public.mensagens 
    FOR EACH ROW 
    EXECUTE FUNCTION update_updated_at_column();

-- 5. Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_mensagens_user_id ON public.mensagens(user_id);
CREATE INDEX IF NOT EXISTS idx_mensagens_status ON public.mensagens(status);
CREATE INDEX IF NOT EXISTS idx_mensagens_created_at ON public.mensagens(created_at);

-- 6. Comentários da tabela
COMMENT ON TABLE public.mensagens IS 'Mensagens dos clientes para o Sicoop';
COMMENT ON COLUMN public.mensagens.id IS 'ID único da mensagem';
COMMENT ON COLUMN public.mensagens.user_id IS 'ID do usuário que criou a mensagem';
COMMENT ON COLUMN public.mensagens.nome IS 'Nome completo do cliente';
COMMENT ON COLUMN public.mensagens.email IS 'E-mail do cliente';
COMMENT ON COLUMN public.mensagens.telefone IS 'Telefone do cliente';
COMMENT ON COLUMN public.mensagens.empresa_fazenda IS 'Nome da empresa ou fazenda';
COMMENT ON COLUMN public.mensagens.mensagem IS 'Conteúdo da mensagem';
COMMENT ON COLUMN public.mensagens.status IS 'Status atual da mensagem (padrão: enviada)';
COMMENT ON COLUMN public.mensagens.created_at IS 'Data de criação da mensagem';
COMMENT ON COLUMN public.mensagens.updated_at IS 'Data da última atualização da mensagem';;
