-- Criar política para usuários técnicos e administradores poderem ver todos os perfis
CREATE POLICY "Tecnicos can view all profiles" ON profiles
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'administrador')
  )
);;
