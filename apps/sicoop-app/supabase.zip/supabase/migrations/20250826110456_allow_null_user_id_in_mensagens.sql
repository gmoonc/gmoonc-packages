-- Permitir que user_id seja NULL na tabela mensagens para permitir atribuição posterior
ALTER TABLE mensagens ALTER COLUMN user_id DROP NOT NULL;;
