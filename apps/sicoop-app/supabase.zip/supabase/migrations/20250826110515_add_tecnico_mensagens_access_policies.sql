-- Criar políticas para usuários técnicos poderem acessar todas as mensagens
CREATE POLICY "Tecnicos can view all messages" ON mensagens
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'administrador')
  )
);

CREATE POLICY "Tecnicos can update all messages" ON mensagens
FOR UPDATE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'administrador')
  )
);

CREATE POLICY "Tecnicos can delete all messages" ON mensagens
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('profiles', 'administrador')
  )
);;
