-- Corrigir a política de DELETE para usuários técnicos
DROP POLICY "Tecnicos can delete all messages" ON mensagens;

CREATE POLICY "Tecnicos can delete all messages" ON mensagens
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'administrador')
  )
);;
