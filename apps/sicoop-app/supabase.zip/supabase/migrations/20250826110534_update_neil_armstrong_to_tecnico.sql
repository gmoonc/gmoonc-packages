-- Alterar o role do usuário Neil Armstrong para 'tecnico'
UPDATE profiles SET role = 'tecnico' WHERE email = 'neil@goalmoon.com';;
