-- Remover a política problemática que causa recursão infinita
DROP POLICY "Tecnicos can view all profiles" ON profiles;

-- Criar uma política mais simples que não cause recursão
CREATE POLICY "Allow authenticated users to view profiles" ON profiles
FOR SELECT
TO public
USING (auth.uid() IS NOT NULL);;
