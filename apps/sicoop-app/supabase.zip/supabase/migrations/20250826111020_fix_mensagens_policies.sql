-- Remover as políticas problemáticas da tabela mensagens
DROP POLICY "Tecnicos can view all messages" ON mensagens;
DROP POLICY "Tecnicos can update all messages" ON mensagens;
DROP POLICY "Tecnicos can delete all messages" ON mensagens;

-- Criar políticas mais simples que não causem recursão
CREATE POLICY "Allow authenticated users to view messages" ON mensagens
FOR SELECT
TO public
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Allow authenticated users to update messages" ON mensagens
FOR UPDATE
TO public
USING (auth.uid() IS NOT NULL);

CREATE POLICY "Allow authenticated users to delete messages" ON mensagens
FOR DELETE
TO public
USING (auth.uid() IS NOT NULL);;
