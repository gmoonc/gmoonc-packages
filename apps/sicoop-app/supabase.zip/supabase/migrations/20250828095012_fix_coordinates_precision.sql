-- Corrigir a precisão dos campos de coordenadas para suportar valores geográficos válidos
ALTER TABLE analises_cobertura 
ALTER COLUMN latitude TYPE numeric(12,8),
ALTER COLUMN longitude TYPE numeric(12,8);

-- Adicionar comentários explicativos
COMMENT ON COLUMN analises_cobertura.latitude IS 'Latitude da propriedade (formato: -90.00000000 a +90.00000000)';
COMMENT ON COLUMN analises_cobertura.longitude IS 'Longitude da propriedade (formato: -180.00000000 a +180.00000000)';;
