-- Step 2: Fix check_permission function
CREATE OR REPLACE FUNCTION public.check_permission(user_id uuid, module_name text, permission_type text DEFAULT 'access')
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  has_permission boolean;
BEGIN
  SELECT 
    CASE 
      WHEN permission_type = 'access' THEN p.can_access
      WHEN permission_type = 'create' THEN p.can_create
      WHEN permission_type = 'read' THEN p.can_read
      WHEN permission_type = 'update' THEN p.can_update
      WHEN permission_type = 'delete' THEN p.can_delete
      ELSE false
    END INTO has_permission
  FROM public.permissions p
  JOIN public.roles r ON p.role_id = r.id
  JOIN public.modules m ON p.module_id = m.id
  JOIN public.profiles pr ON pr.role = r.name
  WHERE pr.id = user_id AND m.name = module_name;
  
  RETURN COALESCE(has_permission, false);
END;
$function$;;
