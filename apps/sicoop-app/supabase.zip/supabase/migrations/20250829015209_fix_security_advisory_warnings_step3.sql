-- Step 3: Fix get_user_permissions function
CREATE OR REPLACE FUNCTION public.get_user_permissions(user_id uuid)
RETURNS TABLE(
  module_name text,
  module_display_name text,
  can_access boolean,
  can_create boolean,
  can_read boolean,
  can_update boolean,
  can_delete boolean
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    m.name,
    m.display_name,
    p.can_access,
    p.can_create,
    p.can_read,
    p.can_update,
    p.can_delete
  FROM public.roles r
  JOIN public.profiles pr ON pr.role = r.name
  LEFT JOIN public.permissions p ON p.role_id = r.id
  LEFT JOIN public.modules m ON p.module_id = m.id
  WHERE pr.id = user_id;
END;
$function$;;
