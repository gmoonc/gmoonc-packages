-- Step 4: Fix remaining functions
-- Fix validate_role_exists function
CREATE OR REPLACE FUNCTION public.validate_role_exists(role_name text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  role_exists boolean;
BEGIN
  SELECT EXISTS(SELECT 1 FROM public.roles WHERE name = role_name) INTO role_exists;
  RETURN role_exists;
END;
$function$;

-- Fix can_delete_role function
CREATE OR REPLACE FUNCTION public.can_delete_role(role_name text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  can_delete boolean;
BEGIN
  SELECT NOT is_system_role INTO can_delete
  FROM public.roles
  WHERE name = role_name;
  
  RETURN COALESCE(can_delete, false);
END;
$function$;;
