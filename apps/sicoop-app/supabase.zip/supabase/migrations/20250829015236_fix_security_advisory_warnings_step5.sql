-- Step 5: Fix get_role_usage_stats function
DROP FUNCTION IF EXISTS public.get_role_usage_stats();

CREATE OR REPLACE FUNCTION public.get_role_usage_stats()
RETURNS TABLE(role_name text, user_count bigint)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  RETURN QUERY
  SELECT r.name, COUNT(p.id)::bigint
  FROM public.roles r
  LEFT JOIN public.profiles p ON p.role = r.name
  GROUP BY r.name;
END;
$function$;;
