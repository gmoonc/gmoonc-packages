-- Fix sync_roles_to_profiles function with correct return type
CREATE OR REPLACE FUNCTION public.sync_roles_to_profiles()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  -- This function should sync roles to profiles
  -- For now, just return the trigger
  RETURN NEW;
END;
$function$;;
