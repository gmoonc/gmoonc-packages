-- Remove trigger first, then fix function
DROP TRIGGER IF EXISTS trigger_validate_role_exists ON public.profiles;

-- Remove duplicate validate_role_exists function
DROP FUNCTION IF EXISTS public.validate_role_exists();

-- Recreate with proper search_path
CREATE OR REPLACE FUNCTION public.validate_role_exists(role_name text)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
DECLARE
  role_exists boolean;
BEGIN
  SELECT EXISTS(SELECT 1 FROM public.roles WHERE name = role_name) INTO role_exists;
  RETURN role_exists;
END;
$function$;;
