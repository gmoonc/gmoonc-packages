-- Criar função RPC para atualizar role do perfil
CREATE OR REPLACE FUNCTION public.update_profile_role(
  user_id uuid,
  new_role text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
BEGIN
  UPDATE public.profiles 
  SET 
    role = new_role::text,
    updated_at = now()
  WHERE id = user_id;
END;
$function$;;
