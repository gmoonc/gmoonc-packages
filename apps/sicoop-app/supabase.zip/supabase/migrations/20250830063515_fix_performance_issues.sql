-- Adicionar índice na foreign key da tabela permissions
CREATE INDEX IF NOT EXISTS idx_permissions_module_id ON public.permissions(module_id);

-- Remover índice não utilizado
DROP INDEX IF EXISTS idx_mensagens_status;;
