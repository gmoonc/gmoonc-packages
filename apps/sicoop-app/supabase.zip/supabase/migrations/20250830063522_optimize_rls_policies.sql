-- Otimizar políticas RLS da tabela mensagens
DROP POLICY IF EXISTS "Users can view own messages" ON public.mensagens;
CREATE POLICY "Users can view own messages" ON public.mensagens
    FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can insert own messages" ON public.mensagens;
CREATE POLICY "Users can insert own messages" ON public.mensagens
    FOR INSERT WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own messages" ON public.mensagens;
CREATE POLICY "Users can update own messages" ON public.mensagens
    FOR UPDATE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own messages" ON public.mensagens;
CREATE POLICY "Users can delete own messages" ON public.mensagens
    FOR DELETE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Admins can view all messages" ON public.mensagens;
CREATE POLICY "Admins can view all messages" ON public.mensagens
    FOR SELECT USING ((select auth.jwt() ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admins can update all messages" ON public.mensagens;
CREATE POLICY "Admins can update all messages" ON public.mensagens
    FOR UPDATE USING ((select auth.jwt() ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admins can delete all messages" ON public.mensagens;
CREATE POLICY "Admins can delete all messages" ON public.mensagens
    FOR DELETE USING ((select auth.jwt() ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Allow authenticated users to view messages" ON public.mensagens;
CREATE POLICY "Allow authenticated users to view messages" ON public.mensagens
    FOR SELECT USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Allow authenticated users to update messages" ON public.mensagens;
CREATE POLICY "Allow authenticated users to update messages" ON public.mensagens
    FOR UPDATE USING (auth.role() = 'authenticated');

DROP POLICY IF EXISTS "Allow authenticated users to delete messages" ON public.mensagens;
CREATE POLICY "Allow authenticated users to delete messages" ON public.mensagens
    FOR DELETE USING (auth.role() = 'authenticated');;
