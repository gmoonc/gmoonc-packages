-- Otimizar políticas RLS da tabela analises_cobertura
DROP POLICY IF EXISTS "Users can view own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can view own analyses" ON public.analises_cobertura
    FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can insert own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can insert own analyses" ON public.analises_cobertura
    FOR INSERT WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can update own analyses" ON public.analises_cobertura
    FOR UPDATE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can delete own analyses" ON public.analises_cobertura
    FOR DELETE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Admins can view all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can view all analyses" ON public.analises_cobertura
    FOR SELECT USING ((select auth.jwt() ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admins can update all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can update all analyses" ON public.analises_cobertura
    FOR UPDATE USING ((select auth.jwt() ->> 'role') = 'admin');

DROP POLICY IF EXISTS "Admins can delete all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can delete all analyses" ON public.analises_cobertura
    FOR DELETE USING ((select auth.jwt() ->> 'role') = 'admin');;
