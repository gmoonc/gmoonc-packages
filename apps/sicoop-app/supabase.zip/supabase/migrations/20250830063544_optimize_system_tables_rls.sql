-- Otimizar políticas RLS da tabela roles
DROP POLICY IF EXISTS "Only admins can manage roles" ON public.roles;
CREATE POLICY "Only admins can manage roles" ON public.roles
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');

-- Otimizar políticas RLS da tabela modules
DROP POLICY IF EXISTS "Only admins can manage modules" ON public.modules;
CREATE POLICY "Only admins can manage modules" ON public.modules
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');

-- Otimizar políticas RLS da tabela permissions
DROP POLICY IF EXISTS "Users can view permissions for their role" ON public.permissions;
CREATE POLICY "Users can view permissions for their role" ON public.permissions
    FOR SELECT USING (true);

DROP POLICY IF EXISTS "Only admins can manage permissions" ON public.permissions;
CREATE POLICY "Only admins can manage permissions" ON public.permissions
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');;
