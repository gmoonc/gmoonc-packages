-- Remover políticas duplicadas e conflitantes
-- Tabela analises_cobertura - consolidar políticas de admin e usuário
DROP POLICY IF EXISTS "Users can view own analyses" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Admins can view all analyses" ON public.analises_cobertura;
CREATE POLICY "Unified analyses access" ON public.analises_cobertura
    FOR SELECT USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin'
    );

DROP POLICY IF EXISTS "Users can update own analyses" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Admins can update all analyses" ON public.analises_cobertura;
CREATE POLICY "Unified analyses update" ON public.analises_cobertura
    FOR UPDATE USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin'
    );

DROP POLICY IF EXISTS "Users can delete own analyses" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Admins can delete all analyses" ON public.analises_cobertura;
CREATE POLICY "Unified analyses delete" ON public.analises_cobertura
    FOR DELETE USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin'
    );

-- Tabela mensagens - consolidar políticas
DROP POLICY IF EXISTS "Users can view own messages" ON public.mensagens;
DROP POLICY IF EXISTS "Admins can view all messages" ON public.mensagens;
DROP POLICY IF EXISTS "Allow authenticated users to view messages" ON public.mensagens;
CREATE POLICY "Unified messages view" ON public.mensagens
    FOR SELECT USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin' OR
        auth.role() = 'authenticated'
    );

DROP POLICY IF EXISTS "Users can update own messages" ON public.mensagens;
DROP POLICY IF EXISTS "Admins can update all messages" ON public.mensagens;
DROP POLICY IF EXISTS "Allow authenticated users to update messages" ON public.mensagens;
CREATE POLICY "Unified messages update" ON public.mensagens
    FOR UPDATE USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin' OR
        auth.role() = 'authenticated'
    );

DROP POLICY IF EXISTS "Users can delete own messages" ON public.mensagens;
DROP POLICY IF EXISTS "Admins can delete all messages" ON public.mensagens;
DROP POLICY IF EXISTS "Allow authenticated users to delete messages" ON public.mensagens;
CREATE POLICY "Unified messages delete" ON public.mensagens
    FOR DELETE USING (
        (select auth.uid()) = user_id OR 
        (select auth.jwt() ->> 'role') = 'admin' OR
        auth.role() = 'authenticated'
    );;
