-- Consolidar políticas da tabela profiles
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
DROP POLICY IF EXISTS "Allow authenticated users to view profiles" ON public.profiles;
CREATE POLICY "Unified profiles view" ON public.profiles
    FOR SELECT USING (
        (select auth.uid()) = id OR 
        (select auth.jwt() ->> 'role') = 'admin' OR
        auth.role() = 'authenticated'
    );

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins can update all profiles" ON public.profiles;
CREATE POLICY "Unified profiles update" ON public.profiles
    FOR UPDATE USING (
        (select auth.uid()) = id OR 
        (select auth.jwt() ->> 'role') = 'admin'
    );

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
DROP POLICY IF EXISTS "Allow profile creation" ON public.profiles;
CREATE POLICY "Unified profiles insert" ON public.profiles
    FOR INSERT WITH CHECK (
        (select auth.uid()) = id OR 
        auth.role() = 'authenticated'
    );

-- Consolidar políticas da tabela modules
DROP POLICY IF EXISTS "Anyone can view modules" ON public.modules;
DROP POLICY IF EXISTS "Only admins can manage modules" ON public.modules;
CREATE POLICY "Unified modules access" ON public.modules
    FOR SELECT USING (true);
CREATE POLICY "Admin modules management" ON public.modules
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');

-- Consolidar políticas da tabela roles
DROP POLICY IF EXISTS "Anyone can view roles" ON public.roles;
DROP POLICY IF EXISTS "Only admins can manage roles" ON public.roles;
CREATE POLICY "Unified roles access" ON public.roles
    FOR SELECT USING (true);
CREATE POLICY "Admin roles management" ON public.roles
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');

-- Consolidar políticas da tabela permissions
DROP POLICY IF EXISTS "Users can view permissions for their role" ON public.permissions;
DROP POLICY IF EXISTS "Only admins can manage permissions" ON public.permissions;
CREATE POLICY "Unified permissions access" ON public.permissions
    FOR SELECT USING (true);
CREATE POLICY "Admin permissions management" ON public.permissions
    FOR ALL USING ((select auth.jwt() ->> 'role') = 'admin');;
