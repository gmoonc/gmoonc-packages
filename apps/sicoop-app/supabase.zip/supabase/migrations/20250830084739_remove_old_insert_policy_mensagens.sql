-- Remover a política antiga que estava causando conflito
DROP POLICY "Users can insert own messages" ON public.mensagens;;
