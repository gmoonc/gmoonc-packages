-- Atualizar a política para incluir o role 'tecnico'
DROP POLICY "Tecnicos can insert messages without assignment" ON public.mensagens;

CREATE POLICY "Tecnicos can insert messages without assignment" ON public.mensagens
FOR INSERT 
TO public
WITH CHECK (
  -- Permitir se o usuário for técnico, funcionário ou administrador
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'funcionario', 'administrador')
  )
  OR
  -- Ou se for o próprio usuário criando sua mensagem
  auth.uid() = user_id
);;
