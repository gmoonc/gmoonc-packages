-- Simplificar a política de inserção para permitir que usuários autenticados criem mensagens
DROP POLICY "Tecnicos can insert messages without assignment" ON public.mensagens;

CREATE POLICY "Authenticated users can insert messages" ON public.mensagens
FOR INSERT 
TO public
WITH CHECK (
  -- Permitir se o usuário estiver autenticado
  auth.role() = 'authenticated'
);;
