-- Criar política para permitir que usuários técnicos criem análises sem atribuição
CREATE POLICY "Tecnicos can insert analyses without assignment" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  -- Permitir se o usuário for técnico (role = 'tecnico', 'funcionario' ou 'administrador')
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE id = auth.uid() 
    AND role IN ('tecnico', 'funcionario', 'administrador')
  )
  OR
  -- Ou se for o próprio usuário criando sua análise
  auth.uid() = user_id
);;
