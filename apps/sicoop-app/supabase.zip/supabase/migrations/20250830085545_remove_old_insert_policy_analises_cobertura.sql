-- Remover a política antiga que estava causando conflito
DROP POLICY "Users can insert own analyses" ON public.analises_cobertura;;
