-- Simplificar a política de inserção para permitir que usuários autenticados criem análises
DROP POLICY "Tecnicos can insert analyses without assignment" ON public.analises_cobertura;

CREATE POLICY "Authenticated users can insert analyses" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  -- Permitir se o usuário estiver autenticado
  auth.role() = 'authenticated'
);;
