-- Corrigir a política de inserção para usar auth.uid() em vez de auth.role()
DROP POLICY "Authenticated users can insert analyses" ON public.analises_cobertura;

CREATE POLICY "Authenticated users can insert analyses" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  -- Permitir se houver um usuário autenticado (auth.uid() não é null)
  auth.uid() IS NOT NULL
);;
