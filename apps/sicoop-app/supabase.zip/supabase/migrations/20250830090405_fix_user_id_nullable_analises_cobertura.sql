-- Alterar a coluna user_id para permitir valores NULL
ALTER TABLE public.analises_cobertura ALTER COLUMN user_id DROP NOT NULL;;
