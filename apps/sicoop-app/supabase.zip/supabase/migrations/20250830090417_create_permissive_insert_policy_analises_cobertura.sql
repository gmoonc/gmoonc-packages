-- Criar uma política mais permissiva para inserção
DROP POLICY "Authenticated users can insert analyses" ON public.analises_cobertura;

CREATE POLICY "Allow all inserts for testing" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (true);;
