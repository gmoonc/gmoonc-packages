-- Replicar exatamente a mesma política que funcionou para mensagens
DROP POLICY "Allow all inserts for testing" ON public.analises_cobertura;

CREATE POLICY "Authenticated users can insert analyses" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  -- Mesma política que funcionou para mensagens
  auth.role() = 'authenticated'
);;
