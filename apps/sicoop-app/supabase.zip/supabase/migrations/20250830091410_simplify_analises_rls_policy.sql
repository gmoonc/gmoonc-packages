-- Recriar a política RLS de forma mais simples
DROP POLICY "Authenticated users can insert analyses" ON public.analises_cobertura;

CREATE POLICY "Anyone authenticated can insert analyses" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  -- Qualquer usuário autenticado pode inserir
  auth.uid() IS NOT NULL
);;
