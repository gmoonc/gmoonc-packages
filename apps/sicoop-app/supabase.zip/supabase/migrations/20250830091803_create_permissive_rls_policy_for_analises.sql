-- Recriar uma política RLS mais permissiva para debug
DROP POLICY "Anyone authenticated can insert analyses" ON public.analises_cobertura;

CREATE POLICY "Insert allowed for authenticated users" ON public.analises_cobertura
FOR INSERT 
TO authenticated
WITH CHECK (true);;
