-- Desabilitar temporariamente o RLS para debug
ALTER TABLE public.analises_cobertura DISABLE ROW LEVEL SECURITY;;
