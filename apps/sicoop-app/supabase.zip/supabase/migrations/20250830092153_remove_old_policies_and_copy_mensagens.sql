-- Remover políticas antigas e copiar exatamente as políticas da tabela mensagens
DROP POLICY IF EXISTS "Insert allowed for authenticated users" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses access" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses delete" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses update" ON public.analises_cobertura;

-- Política para INSERT (igual à de mensagens)
CREATE POLICY "Authenticated users can insert analyses" ON public.analises_cobertura
FOR INSERT 
TO public
WITH CHECK (
  auth.role() = 'authenticated'
);

-- Política para SELECT (igual à de mensagens)
CREATE POLICY "Unified analyses view" ON public.analises_cobertura
FOR SELECT 
TO public
USING (
  ((SELECT auth.uid() AS uid) = user_id) OR 
  ((SELECT (auth.jwt() ->> 'role'::text)) = 'admin'::text) OR 
  (auth.role() = 'authenticated'::text)
);

-- Política para UPDATE (igual à de mensagens)
CREATE POLICY "Unified analyses update" ON public.analises_cobertura
FOR UPDATE 
TO public
USING (
  ((SELECT auth.uid() AS uid) = user_id) OR 
  ((SELECT (auth.jwt() ->> 'role'::text)) = 'admin'::text) OR 
  (auth.role() = 'authenticated'::text)
);

-- Política para DELETE (igual à de mensagens)
CREATE POLICY "Unified analyses delete" ON public.analises_cobertura
FOR DELETE 
TO public
USING (
  ((SELECT auth.uid() AS uid) = user_id) OR 
  ((SELECT (auth.jwt() ->> 'role'::text)) = 'admin'::text) OR 
  (auth.role() = 'authenticated'::text)
);;
