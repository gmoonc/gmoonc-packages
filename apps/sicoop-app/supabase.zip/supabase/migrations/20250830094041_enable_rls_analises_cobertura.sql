ALTER TABLE public.analises_cobertura ENABLE ROW LEVEL SECURITY;;
