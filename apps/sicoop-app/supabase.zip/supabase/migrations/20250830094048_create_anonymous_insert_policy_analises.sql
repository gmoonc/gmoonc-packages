CREATE POLICY "Anonymous users can insert analyses" ON public.analises_cobertura
FOR INSERT TO anon
WITH CHECK (true);;
