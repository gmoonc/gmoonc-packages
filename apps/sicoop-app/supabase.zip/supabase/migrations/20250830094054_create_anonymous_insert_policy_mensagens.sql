CREATE POLICY "Anonymous users can insert messages" ON public.mensagens
FOR INSERT TO anon
WITH CHECK (true);;
