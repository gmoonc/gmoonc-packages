DROP POLICY IF EXISTS "Authenticated users can insert analyses" ON public.analises_cobertura;;
