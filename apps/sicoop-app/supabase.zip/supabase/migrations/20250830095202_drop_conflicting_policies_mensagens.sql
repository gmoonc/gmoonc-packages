DROP POLICY IF EXISTS "Authenticated users can insert messages" ON public.mensagens;;
