DROP POLICY IF EXISTS "Anonymous users can insert messages" ON public.mensagens;

CREATE POLICY "Anonymous users can insert messages" ON public.mensagens
FOR INSERT TO anon
WITH CHECK (true);;
