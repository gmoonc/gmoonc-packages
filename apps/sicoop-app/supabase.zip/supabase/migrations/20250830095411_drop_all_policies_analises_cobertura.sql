DROP POLICY IF EXISTS "Anonymous users can insert analyses" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses delete" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses update" ON public.analises_cobertura;
DROP POLICY IF EXISTS "Unified analyses view" ON public.analises_cobertura;;
