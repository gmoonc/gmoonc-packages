CREATE POLICY "Allow all inserts" ON public.analises_cobertura
FOR INSERT TO anon, authenticated
WITH CHECK (true);;
