CREATE POLICY "Allow all views" ON public.analises_cobertura
FOR SELECT TO anon, authenticated
USING (true);;
