DROP POLICY IF EXISTS "Anonymous users can insert messages" ON public.mensagens;
DROP POLICY IF EXISTS "Unified messages delete" ON public.mensagens;
DROP POLICY IF EXISTS "Unified messages update" ON public.mensagens;
DROP POLICY IF EXISTS "Unified messages view" ON public.mensagens;;
