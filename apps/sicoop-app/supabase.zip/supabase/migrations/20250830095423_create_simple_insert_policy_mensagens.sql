CREATE POLICY "Allow all inserts" ON public.mensagens
FOR INSERT TO anon, authenticated
WITH CHECK (true);;
