CREATE POLICY "Allow all views" ON public.mensagens
FOR SELECT TO anon, authenticated
USING (true);;
