-- Migration: create_notifications_system.sql
-- Description: Sistema de notificações por email para o Sicoop
-- Date: 2025-01-27

-- 1. Criar tabela de categorias de notificação
CREATE TABLE IF NOT EXISTS public.notification_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    email_template_subject TEXT NOT NULL,
    email_template_body TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Criar tabela de configurações de notificação por usuário
CREATE TABLE IF NOT EXISTS public.notification_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    category_id UUID REFERENCES public.notification_categories(id) ON DELETE CASCADE NOT NULL,
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, category_id)
);

-- 3. Criar tabela de logs de notificações
CREATE TABLE IF NOT EXISTS public.notification_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    category_id UUID REFERENCES public.notification_categories(id) ON DELETE CASCADE NOT NULL,
    user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE NOT NULL,
    entity_type TEXT NOT NULL, -- 'mensagem' ou 'analise'
    entity_id UUID NOT NULL, -- ID da mensagem ou análise
    email_sent BOOLEAN DEFAULT false,
    email_error TEXT,
    sent_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Habilitar RLS
ALTER TABLE public.notification_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_logs ENABLE ROW LEVEL SECURITY;

-- 5. Políticas de segurança para categorias de notificação
-- Apenas administradores podem gerenciar categorias
CREATE POLICY "Admins can manage notification categories" ON public.notification_categories
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 6. Políticas de segurança para configurações de notificação
-- Usuários podem ver suas próprias configurações
CREATE POLICY "Users can view own notification settings" ON public.notification_settings
    FOR SELECT USING (auth.uid() = user_id);

-- Usuários podem atualizar suas próprias configurações
CREATE POLICY "Users can update own notification settings" ON public.notification_settings
    FOR UPDATE USING (auth.uid() = user_id);

-- Administradores podem gerenciar todas as configurações
CREATE POLICY "Admins can manage all notification settings" ON public.notification_settings
    FOR ALL USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 7. Políticas de segurança para logs de notificação
-- Apenas administradores podem ver logs
CREATE POLICY "Admins can view notification logs" ON public.notification_logs
    FOR SELECT USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- 8. Inserir categorias padrão
INSERT INTO public.notification_categories (name, display_name, description, email_template_subject, email_template_body) VALUES
    ('nova_mensagem', 'Notificações de Novas Mensagens', 'Notificações quando novas mensagens são enviadas pelos clientes', 
     'Nova mensagem recebida - Sicoop', 
     'Uma nova mensagem foi recebida no sistema Sicoop.\n\nDetalhes:\n- Nome: {{nome}}\n- Email: {{email}}\n- Empresa/Fazenda: {{empresa_fazenda}}\n- Mensagem: {{mensagem}}\n\nAcesse o sistema para visualizar e responder.'),
    ('nova_analise', 'Notificações de Novas Análises', 'Notificações quando novas análises de cobertura são solicitadas', 
     'Nova análise de cobertura solicitada - Sicoop', 
     'Uma nova análise de cobertura foi solicitada no sistema Sicoop.\n\nDetalhes:\n- Nome: {{nome}}\n- Email: {{email}}\n- Fazenda: {{nome_fazenda}}\n- Área: {{area_fazenda_ha}} ha\n- Observações: {{observacoes}}\n\nAcesse o sistema para processar a solicitação.')
ON CONFLICT (name) DO NOTHING;

-- 9. Criar triggers para atualizar timestamps
CREATE TRIGGER update_notification_categories_updated_at 
    BEFORE UPDATE ON public.notification_categories 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_notification_settings_updated_at 
    BEFORE UPDATE ON public.notification_settings 
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- 10. Criar função para obter usuários que devem receber notificações de uma categoria
CREATE OR REPLACE FUNCTION public.get_notification_recipients(category_name TEXT)
RETURNS TABLE(
    user_id UUID,
    email TEXT,
    name TEXT
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.email,
        p.name
    FROM public.profiles p
    JOIN public.notification_settings ns ON p.id = ns.user_id
    JOIN public.notification_categories nc ON ns.category_id = nc.id
    WHERE nc.name = category_name 
    AND ns.is_enabled = true 
    AND nc.is_active = true
    AND p.role = 'administrador';
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 11. Criar função para registrar log de notificação
CREATE OR REPLACE FUNCTION public.log_notification(
    p_category_name TEXT,
    p_user_id UUID,
    p_entity_type TEXT,
    p_entity_id UUID,
    p_email_sent BOOLEAN DEFAULT false,
    p_email_error TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    category_id UUID;
    log_id UUID;
BEGIN
    -- Buscar ID da categoria
    SELECT id INTO category_id
    FROM public.notification_categories
    WHERE name = p_category_name;
    
    IF category_id IS NULL THEN
        RAISE EXCEPTION 'Categoria de notificação não encontrada: %', p_category_name;
    END IF;
    
    -- Inserir log
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at
    ) VALUES (
        category_id,
        p_user_id,
        p_entity_type,
        p_entity_id,
        p_email_sent,
        p_email_error,
        CASE WHEN p_email_sent THEN NOW() ELSE NULL END
    ) RETURNING id INTO log_id;
    
    RETURN log_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
