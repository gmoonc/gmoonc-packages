-- Migration: create_notification_triggers.sql
-- Description: Triggers para detectar novas mensagens e análises e enviar notificações
-- Date: 2025-01-27

-- 1. Criar função para enviar notificação via Edge Function
CREATE OR REPLACE FUNCTION public.send_notification_email(
    p_category TEXT,
    p_entity_type TEXT,
    p_entity_id UUID,
    p_entity_data JSONB
)
RETURNS void AS $$
DECLARE
    response TEXT;
    error_msg TEXT;
BEGIN
    -- Chamar Edge Function via HTTP
    SELECT content INTO response
    FROM http((
        'POST',
        current_setting('app.settings.supabase_url') || '/functions/v1/send-notification-email',
        ARRAY[
            http_header('Authorization', 'Bearer ' || current_setting('app.settings.supabase_anon_key')),
            http_header('Content-Type', 'application/json')
        ],
        'application/json',
        json_build_object(
            'category', p_category,
            'entityType', p_entity_type,
            'entityId', p_entity_id,
            'entityData', p_entity_data
        )::text
    ));
    
    -- Log da resposta (opcional)
    RAISE NOTICE 'Resposta da Edge Function: %', response;
    
EXCEPTION WHEN OTHERS THEN
    error_msg := SQLERRM;
    RAISE WARNING 'Erro ao enviar notificação: %', error_msg;
    -- Não falhar a operação principal se a notificação falhar
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Criar função para processar nova mensagem
CREATE OR REPLACE FUNCTION public.handle_new_mensagem()
RETURNS TRIGGER AS $$
DECLARE
    entity_data JSONB;
BEGIN
    -- Preparar dados da mensagem para o template
    entity_data := jsonb_build_object(
        'id', NEW.id,
        'nome', NEW.nome,
        'email', NEW.email,
        'telefone', COALESCE(NEW.telefone, ''),
        'empresa_fazenda', NEW.empresa_fazenda,
        'mensagem', NEW.mensagem,
        'status', COALESCE(NEW.status, 'enviada'),
        'created_at', NEW.created_at
    );
    
    -- Enviar notificação (assíncrono)
    PERFORM public.send_notification_email(
        'nova_mensagem',
        'mensagem',
        NEW.id,
        entity_data
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Criar função para processar nova análise
CREATE OR REPLACE FUNCTION public.handle_new_analise()
RETURNS TRIGGER AS $$
DECLARE
    entity_data JSONB;
BEGIN
    -- Preparar dados da análise para o template
    entity_data := jsonb_build_object(
        'id', NEW.id,
        'nome', NEW.nome,
        'email', NEW.email,
        'telefone', COALESCE(NEW.telefone, ''),
        'nome_fazenda', NEW.nome_fazenda,
        'area_fazenda_ha', COALESCE(NEW.area_fazenda_ha, 0),
        'latitude', COALESCE(NEW.latitude, 0),
        'longitude', COALESCE(NEW.longitude, 0),
        'observacoes', COALESCE(NEW.observacoes, ''),
        'status', COALESCE(NEW.status, 'solicitada'),
        'created_at', NEW.created_at
    );
    
    -- Enviar notificação (assíncrono)
    PERFORM public.send_notification_email(
        'nova_analise',
        'analise',
        NEW.id,
        entity_data
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Criar triggers
CREATE TRIGGER trigger_new_mensagem_notification
    AFTER INSERT ON public.mensagens
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_mensagem();

CREATE TRIGGER trigger_new_analise_notification
    AFTER INSERT ON public.analises_cobertura
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_analise();

-- 5. Configurar variáveis de ambiente (se necessário)
-- Nota: Estas configurações devem ser feitas no painel do Supabase
-- ALTER DATABASE postgres SET app.settings.supabase_url = 'https://seu-projeto.supabase.co';
-- ALTER DATABASE postgres SET app.settings.supabase_anon_key = 'sua-chave-anonima';;
