-- Migration: fix_notification_triggers_no_http.sql
-- Description: Corrigir triggers de notificação sem usar extensão HTTP
-- Date: 2025-01-27

-- 1. Remover triggers e funções problemáticas
DROP TRIGGER IF EXISTS trigger_new_mensagem_notification ON public.mensagens;
DROP TRIGGER IF EXISTS trigger_new_analise_notification ON public.analises_cobertura;
DROP FUNCTION IF EXISTS public.handle_new_mensagem();
DROP FUNCTION IF EXISTS public.handle_new_analise();
DROP FUNCTION IF EXISTS public.queue_notification(TEXT, TEXT, UUID, JSONB);
DROP FUNCTION IF EXISTS public.process_pending_notifications();

-- 2. Criar função simplificada para registrar notificação pendente
CREATE OR REPLACE FUNCTION public.queue_notification(
    p_category TEXT,
    p_entity_type TEXT,
    p_entity_id UUID,
    p_entity_data JSONB
)
RETURNS void AS $$
BEGIN
    -- Inserir na tabela de logs como pendente
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at
    )
    SELECT 
        nc.id,
        p.id,
        p_entity_type,
        p_entity_id,
        false,
        'Pendente de processamento',
        NULL
    FROM public.profiles p
    CROSS JOIN public.notification_categories nc
    WHERE nc.name = p_category 
    AND nc.is_active = true
    AND p.role = 'administrador'
    AND EXISTS (
        SELECT 1 FROM public.notification_settings ns
        WHERE ns.user_id = p.id 
        AND ns.category_id = nc.id 
        AND ns.is_enabled = true
    );
    
    -- Log da operação
    RAISE NOTICE 'Notificação enfileirada: categoria=%, entidade=%, id=%', p_category, p_entity_type, p_entity_id;
    
EXCEPTION WHEN OTHERS THEN
    RAISE WARNING 'Erro ao enfileirar notificação: %', SQLERRM;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Criar função para processar nova mensagem
CREATE OR REPLACE FUNCTION public.handle_new_mensagem()
RETURNS TRIGGER AS $$
DECLARE
    entity_data JSONB;
BEGIN
    -- Preparar dados da mensagem para o template
    entity_data := jsonb_build_object(
        'id', NEW.id,
        'nome', NEW.nome,
        'email', NEW.email,
        'telefone', COALESCE(NEW.telefone, ''),
        'empresa_fazenda', NEW.empresa_fazenda,
        'mensagem', NEW.mensagem,
        'status', COALESCE(NEW.status, 'enviada'),
        'created_at', NEW.created_at
    );
    
    -- Enfileirar notificação
    PERFORM public.queue_notification(
        'nova_mensagem',
        'mensagem',
        NEW.id,
        entity_data
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 4. Criar função para processar nova análise
CREATE OR REPLACE FUNCTION public.handle_new_analise()
RETURNS TRIGGER AS $$
DECLARE
    entity_data JSONB;
BEGIN
    -- Preparar dados da análise para o template
    entity_data := jsonb_build_object(
        'id', NEW.id,
        'nome', NEW.nome,
        'email', NEW.email,
        'telefone', COALESCE(NEW.telefone, ''),
        'nome_fazenda', NEW.nome_fazenda,
        'area_fazenda_ha', COALESCE(NEW.area_fazenda_ha, 0),
        'latitude', COALESCE(NEW.latitude, 0),
        'longitude', COALESCE(NEW.longitude, 0),
        'observacoes', COALESCE(NEW.observacoes, ''),
        'status', COALESCE(NEW.status, 'solicitada'),
        'created_at', NEW.created_at
    );
    
    -- Enfileirar notificação
    PERFORM public.queue_notification(
        'nova_analise',
        'analise',
        NEW.id,
        entity_data
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 5. Criar triggers
CREATE TRIGGER trigger_new_mensagem_notification
    AFTER INSERT ON public.mensagens
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_mensagem();

CREATE TRIGGER trigger_new_analise_notification
    AFTER INSERT ON public.analises_cobertura
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_analise();

-- 6. Criar função para processar notificações pendentes (versão simplificada)
CREATE OR REPLACE FUNCTION public.process_pending_notifications()
RETURNS TABLE(
    processed_count INTEGER,
    success_count INTEGER,
    error_count INTEGER
) AS $$
DECLARE
    notification_record RECORD;
    processed_count INTEGER := 0;
    success_count INTEGER := 0;
    error_count INTEGER := 0;
BEGIN
    -- Processar notificações pendentes
    FOR notification_record IN
        SELECT 
            nl.id as log_id,
            nc.name as category_name,
            p.email as user_email,
            p.name as user_name,
            nl.entity_type,
            nl.entity_id,
            nl.created_at
        FROM public.notification_logs nl
        JOIN public.notification_categories nc ON nl.category_id = nc.id
        JOIN public.profiles p ON nl.user_id = p.id
        WHERE nl.email_sent = false
        AND nl.email_error = 'Pendente de processamento'
        ORDER BY nl.created_at ASC
        LIMIT 10 -- Processar em lotes de 10
    LOOP
        processed_count := processed_count + 1;
        
        BEGIN
            -- Marcar como processada (mas não enviar email ainda)
            -- O envio será feito via Edge Function chamada manualmente
            UPDATE public.notification_logs
            SET 
                email_sent = true,
                email_error = 'Processada - aguardando envio via Edge Function',
                sent_at = NOW()
            WHERE id = notification_record.log_id;
            
            success_count := success_count + 1;
            
        EXCEPTION WHEN OTHERS THEN
            -- Atualizar log com erro
            UPDATE public.notification_logs
            SET 
                email_sent = false,
                email_error = SQLERRM,
                sent_at = NULL
            WHERE id = notification_record.log_id;
            
            error_count := error_count + 1;
        END;
    END LOOP;
    
    RETURN QUERY SELECT processed_count, success_count, error_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
