-- Garantir que as foreign keys estejam corretas e reconhecidas pelo Supabase
ALTER TABLE notification_settings 
  DROP CONSTRAINT IF EXISTS notification_settings_user_id_fkey,
  DROP CONSTRAINT IF EXISTS notification_settings_category_id_fkey;

-- Recriar as foreign keys com nomes explícitos
ALTER TABLE notification_settings 
  ADD CONSTRAINT notification_settings_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;

ALTER TABLE notification_settings 
  ADD CONSTRAINT notification_settings_category_id_fkey 
  FOREIGN KEY (category_id) REFERENCES notification_categories(id) ON DELETE CASCADE;

-- Garantir que os índices existam para performance
CREATE INDEX IF NOT EXISTS idx_notification_settings_user_id ON notification_settings(user_id);
CREATE INDEX IF NOT EXISTS idx_notification_settings_category_id ON notification_settings(category_id);

-- Atualizar as estatísticas das tabelas
ANALYZE notification_settings;
ANALYZE notification_categories;
ANALYZE profiles;;
