-- Reverter as mudanças nas foreign keys que quebraram o banco
-- Remover as foreign keys que criei
ALTER TABLE notification_settings 
  DROP CONSTRAINT IF EXISTS notification_settings_user_id_fkey,
  DROP CONSTRAINT IF EXISTS notification_settings_category_id_fkey;

-- Recriar as foreign keys originais (se existiam)
-- Primeiro, verificar se as tabelas originais tinham foreign keys
-- Vou recriar apenas as foreign keys necessárias sem afetar outras tabelas

-- Recriar foreign key para notification_settings -> notification_categories
ALTER TABLE notification_settings 
  ADD CONSTRAINT notification_settings_category_id_fkey 
  FOREIGN KEY (category_id) REFERENCES notification_categories(id) ON DELETE CASCADE;

-- Recriar foreign key para notification_settings -> profiles (se existia)
-- Mas sem afetar a tabela profiles
ALTER TABLE notification_settings 
  ADD CONSTRAINT notification_settings_user_id_fkey 
  FOREIGN KEY (user_id) REFERENCES profiles(id) ON DELETE CASCADE;

-- Manter apenas os índices que criei para performance
-- (estes não afetam outras tabelas);
