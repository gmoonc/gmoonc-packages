-- Desabilitar triggers antigos que podem estar causando problemas
DROP TRIGGER IF EXISTS trigger_new_mensagem_notification ON mensagens;
DROP TRIGGER IF EXISTS trigger_new_analise_notification ON analises_cobertura;

-- Manter apenas os triggers novos que criamos
-- (os triggers trigger_notify_new_mensagem e trigger_notify_new_analise já estão ativos);
