-- Corrigir o trigger para usar o tipo correto de entity_id
CREATE OR REPLACE FUNCTION process_notification_automatically()
RETURNS TRIGGER AS $$
DECLARE
    category_name TEXT;
    entity_data JSONB;
BEGIN
    -- Determinar categoria baseada na tabela
    IF TG_TABLE_NAME = 'mensagens' THEN
        category_name := 'nova_mensagem';
        entity_data := jsonb_build_object(
            'nome', COALESCE(NEW.nome, ''),
            'email', COALESCE(NEW.email, ''),
            'empresa_fazenda', COALESCE(NEW.empresa_fazenda, ''),
            'mensagem', COALESCE(NEW.mensagem, ''),
            'status', COALESCE(NEW.status, ''),
            'created_at', NEW.created_at
        );
    ELSIF TG_TABLE_NAME = 'analises_cobertura' THEN
        category_name := 'nova_analise';
        entity_data := jsonb_build_object(
            'nome', COALESCE(NEW.nome, ''),
            'email', COALESCE(NEW.email, ''),
            'nome_fazenda', COALESCE(NEW.nome_fazenda, ''),
            'area_fazenda_ha', COALESCE(NEW.area_fazenda_ha, 0),
            'observacoes', COALESCE(NEW.observacoes, ''),
            'status', COALESCE(NEW.status, ''),
            'created_at', NEW.created_at
        );
    ELSE
        RETURN NEW;
    END IF;

    -- Buscar destinatários para a categoria
    PERFORM get_notification_recipients(category_name);
    
    -- Processar notificações via Edge Function
    PERFORM net.http_post(
        url := 'https://itrnlqdcbccyzqtymfju.supabase.co/functions/v1/send-notification-email-v2',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer ' || current_setting('app.settings.service_role_key', true)
        ),
        body := jsonb_build_object(
            'category', category_name,
            'entityType', CASE 
                WHEN TG_TABLE_NAME = 'mensagens' THEN 'mensagem'
                ELSE 'analise'
            END,
            'entityId', NEW.id::text,
            'entityData', entity_data
        )
    );

    RETURN NEW;
EXCEPTION
    WHEN OTHERS THEN
        -- Log do erro sem interromper a operação
        INSERT INTO notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            email_sent,
            email_error,
            created_at
        ) VALUES (
            (SELECT id FROM notification_categories WHERE name = category_name LIMIT 1),
            '00000000-0000-0000-0000-000000000000'::uuid, -- UUID dummy para erros de sistema
            CASE 
                WHEN TG_TABLE_NAME = 'mensagens' THEN 'mensagem'
                ELSE 'analise'
            END,
            NEW.id::text, -- Corrigido: usar text para entity_id
            false,
            'Erro no trigger: ' || SQLERRM,
            NOW()
        );
        RETURN NEW;
END;
$$ LANGUAGE plpgsql;;
