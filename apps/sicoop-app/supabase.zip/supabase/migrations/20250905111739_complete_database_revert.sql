-- REVERTER COMPLETAMENTE O BANCO PARA O ESTADO ORIGINAL
-- Remover todos os triggers que criei
DROP TRIGGER IF EXISTS trigger_notify_new_mensagem ON mensagens;
DROP TRIGGER IF EXISTS trigger_notify_new_analise ON analises_cobertura;
DROP TRIGGER IF EXISTS trigger_new_mensagem_notification ON mensagens;
DROP TRIGGER IF EXISTS trigger_new_analise_notification ON analises_cobertura;

-- Remover todas as funções que criei
DROP FUNCTION IF EXISTS process_notification_automatically();
DROP FUNCTION IF EXISTS get_notification_recipients(TEXT);
DROP FUNCTION IF EXISTS log_notification(TEXT, UUID, TEXT, TEXT, BOOLEAN, TEXT);
DROP FUNCTION IF EXISTS process_pending_notifications();

-- Remover todas as tabelas que criei
DROP TABLE IF EXISTS notification_logs CASCADE;
DROP TABLE IF EXISTS notification_settings CASCADE;
DROP TABLE IF EXISTS notification_categories CASCADE;

-- Remover índices que criei
DROP INDEX IF EXISTS idx_notification_settings_user_id;
DROP INDEX IF EXISTS idx_notification_settings_category_id;;
