-- Criar tabelas de notificação de forma segura
-- 1. Tabela de categorias de notificação
CREATE TABLE IF NOT EXISTS notification_categories (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL UNIQUE,
  display_name TEXT NOT NULL,
  description TEXT,
  is_active BOOLEAN DEFAULT true,
  email_template_subject TEXT NOT NULL DEFAULT 'Nova Notificação',
  email_template_body TEXT NOT NULL DEFAULT 'Você tem uma nova notificação.',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Tabela de configurações de notificação (sem foreign key para profiles)
CREATE TABLE IF NOT EXISTS notification_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL, -- Referência para profiles, mas sem FK para não quebrar
  category_id UUID NOT NULL REFERENCES notification_categories(id) ON DELETE CASCADE,
  is_enabled BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, category_id)
);

-- 3. Tabela de logs de notificação (sem foreign keys)
CREATE TABLE IF NOT EXISTS notification_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  category_id UUID NOT NULL REFERENCES notification_categories(id) ON DELETE CASCADE,
  user_id UUID NOT NULL, -- Referência para profiles, mas sem FK
  entity_type TEXT NOT NULL, -- 'mensagem' ou 'analise'
  entity_id TEXT NOT NULL, -- ID da entidade como texto
  email_sent BOOLEAN NOT NULL DEFAULT false,
  email_error TEXT,
  sent_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_notification_settings_user_id ON notification_settings(user_id);
CREATE INDEX IF NOT EXISTS idx_notification_settings_category_id ON notification_settings(category_id);
CREATE INDEX IF NOT EXISTS idx_notification_logs_created_at ON notification_logs(created_at DESC);;
