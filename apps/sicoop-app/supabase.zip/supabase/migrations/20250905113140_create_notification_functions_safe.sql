-- Criar funções auxiliares para notificações
-- 1. Função para buscar destinatários de uma categoria
CREATE OR REPLACE FUNCTION get_notification_recipients(category_name TEXT)
RETURNS TABLE(user_id UUID, email TEXT, name TEXT) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ns.user_id,
    p.email,
    p.name
  FROM notification_settings ns
  JOIN profiles p ON p.id = ns.user_id
  JOIN notification_categories nc ON nc.id = ns.category_id
  WHERE nc.name = category_name 
    AND ns.is_enabled = true
    AND nc.is_active = true;
END;
$$ LANGUAGE plpgsql;

-- 2. Função para registrar log de notificação
CREATE OR REPLACE FUNCTION log_notification(
  p_category_name TEXT,
  p_user_id UUID,
  p_entity_type TEXT,
  p_entity_id TEXT,
  p_email_sent BOOLEAN,
  p_email_error TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
  log_id UUID;
  category_id UUID;
BEGIN
  -- Buscar ID da categoria
  SELECT id INTO category_id 
  FROM notification_categories 
  WHERE name = p_category_name 
  LIMIT 1;
  
  -- Inserir log
  INSERT INTO notification_logs (
    category_id,
    user_id,
    entity_type,
    entity_id,
    email_sent,
    email_error,
    sent_at
  ) VALUES (
    category_id,
    p_user_id,
    p_entity_type,
    p_entity_id,
    p_email_sent,
    p_email_error,
    CASE WHEN p_email_sent THEN NOW() ELSE NULL END
  ) RETURNING id INTO log_id;
  
  RETURN log_id;
END;
$$ LANGUAGE plpgsql;;
