-- Criar sistema de notificações manual (mais seguro)
-- Função para processar notificações pendentes manualmente
CREATE OR REPLACE FUNCTION process_manual_notifications(
  p_entity_type TEXT,
  p_entity_id TEXT,
  p_entity_data JSONB
)
RETURNS TABLE(success BOOLEAN, message TEXT, recipient_count INTEGER) AS $$
DECLARE
  category_name TEXT;
  recipient RECORD;
  success_count INTEGER := 0;
  total_recipients INTEGER := 0;
BEGIN
  -- Determinar categoria baseada no tipo de entidade
  IF p_entity_type = 'mensagem' THEN
    category_name := 'nova_mensagem';
  ELSIF p_entity_type = 'analise' THEN
    category_name := 'nova_analise';
  ELSE
    RETURN QUERY SELECT false, 'Tipo de entidade inválido', 0;
    RETURN;
  END IF;
  
  -- Buscar destinatários
  FOR recipient IN 
    SELECT * FROM get_notification_recipients(category_name)
  LOOP
    total_recipients := total_recipients + 1;
    
    -- Registrar log (simulado por enquanto)
    PERFORM log_notification(
      category_name,
      recipient.user_id,
      p_entity_type,
      p_entity_id,
      true, -- Simular sucesso
      NULL
    );
    
    success_count := success_count + 1;
  END LOOP;
  
  RETURN QUERY SELECT true, 'Notificações processadas com sucesso', total_recipients;
END;
$$ LANGUAGE plpgsql;;
