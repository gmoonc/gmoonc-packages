-- REVERTER COMPLETAMENTE TUDO NOVAMENTE
-- Remover todas as tabelas de notificação
DROP TABLE IF EXISTS notification_logs CASCADE;
DROP TABLE IF EXISTS notification_settings CASCADE;
DROP TABLE IF EXISTS notification_categories CASCADE;

-- Remover todas as funções de notificação
DROP FUNCTION IF EXISTS process_manual_notifications(TEXT, TEXT, JSONB);
DROP FUNCTION IF EXISTS get_notification_recipients(TEXT);
DROP FUNCTION IF EXISTS log_notification(TEXT, UUID, TEXT, TEXT, BOOLEAN, TEXT);

-- Remover índices
DROP INDEX IF EXISTS idx_notification_settings_user_id;
DROP INDEX IF EXISTS idx_notification_settings_category_id;
DROP INDEX IF EXISTS idx_notification_logs_created_at;;
