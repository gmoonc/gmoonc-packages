-- REVERTER COMPLETAMENTE O SISTEMA PARA O ESTADO INICIAL
-- Remover TODAS as tabelas de notificação
DROP TABLE IF EXISTS notification_logs CASCADE;
DROP TABLE IF EXISTS notification_settings CASCADE;
DROP TABLE IF EXISTS notification_categories CASCADE;

-- Remover TODAS as funções de notificação
DROP FUNCTION IF EXISTS process_manual_notifications(TEXT, TEXT, JSONB);
DROP FUNCTION IF EXISTS process_manual_notifications();
DROP FUNCTION IF EXISTS get_notification_recipients(TEXT);
DROP FUNCTION IF EXISTS log_notification(TEXT, UUID, TEXT, TEXT, BOOLEAN, TEXT);
DROP FUNCTION IF EXISTS queue_notification(TEXT, TEXT, UUID);

-- Remover TODOS os triggers de notificação
DROP TRIGGER IF EXISTS trigger_notify_new_analise ON analises_cobertura;
DROP TRIGGER IF EXISTS trigger_notify_new_mensagem ON mensagens;
DROP TRIGGER IF EXISTS trigger_notify_new_analise_simple ON analises_cobertura;
DROP TRIGGER IF EXISTS trigger_notify_new_mensagem_simple ON mensagens;

-- Remover TODAS as funções de trigger
DROP FUNCTION IF EXISTS notify_new_analise();
DROP FUNCTION IF EXISTS notify_new_mensagem();
DROP FUNCTION IF EXISTS notify_new_analise_simple();
DROP FUNCTION IF EXISTS notify_new_mensagem_simple();

-- Remover TODOS os índices de notificação
DROP INDEX IF EXISTS idx_notification_settings_user_id;
DROP INDEX IF EXISTS idx_notification_settings_category_id;
DROP INDEX IF EXISTS idx_notification_logs_created_at;
DROP INDEX IF EXISTS idx_notification_logs_entity_type;
DROP INDEX IF EXISTS idx_notification_logs_email_sent;

-- Verificar se as tabelas principais ainda existem e funcionam
-- (não vamos tocar nelas, apenas verificar);
