-- RESTAURAÇÃO COMPLETA DO SISTEMA
-- Baseado na análise do histórico da thread

-- 1. Remover QUALQUER resíduo de notificações
DROP TABLE IF EXISTS notification_logs CASCADE;
DROP TABLE IF EXISTS notification_settings CASCADE; 
DROP TABLE IF EXISTS notification_categories CASCADE;

-- 2. Remover TODAS as funções relacionadas a notificações
DROP FUNCTION IF EXISTS process_manual_notifications() CASCADE;
DROP FUNCTION IF EXISTS get_notification_recipients(TEXT) CASCADE;
DROP FUNCTION IF EXISTS log_notification(TEXT, UUID, TEXT, TEXT, BOOLEAN, TEXT) CASCADE;
DROP FUNCTION IF EXISTS queue_notification(TEXT, TEXT, UUID) CASCADE;
DROP FUNCTION IF EXISTS queue_notification(TEXT, TEXT, UUID, JSONB) CASCADE;
DROP FUNCTION IF EXISTS notify_new_analise() CASCADE;
DROP FUNCTION IF EXISTS notify_new_mensagem() CASCADE;
DROP FUNCTION IF EXISTS notify_new_analise_simple() CASCADE;
DROP FUNCTION IF EXISTS notify_new_mensagem_simple() CASCADE;

-- 3. Remover TODOS os triggers de notificação
DROP TRIGGER IF EXISTS trigger_notify_new_analise ON analises_cobertura;
DROP TRIGGER IF EXISTS trigger_notify_new_mensagem ON mensagens;
DROP TRIGGER IF EXISTS trigger_notify_new_analise_simple ON analises_cobertura;
DROP TRIGGER IF EXISTS trigger_notify_new_mensagem_simple ON mensagens;

-- 4. Remover índices de notificação
DROP INDEX IF EXISTS idx_notification_settings_user_id;
DROP INDEX IF EXISTS idx_notification_settings_category_id;
DROP INDEX IF EXISTS idx_notification_logs_created_at;
DROP INDEX IF EXISTS idx_notification_logs_entity_type;
DROP INDEX IF EXISTS idx_notification_logs_email_sent;

-- 5. Verificar se as políticas RLS estão corretas para as tabelas principais
-- (Não vamos modificar, apenas garantir que existem)

-- 6. Limpar qualquer sequência ou tipo personalizado que possa ter sido criado
DROP TYPE IF EXISTS notification_status CASCADE;
DROP TYPE IF EXISTS notification_category_type CASCADE;

-- Sistema deve estar limpo agora;
