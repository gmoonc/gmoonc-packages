-- PASSO 1: Criar tabelas de notificação (sem foreign keys para segurança)
-- 1. Tabela de categorias de notificação
CREATE TABLE IF NOT EXISTS public.notification_categories (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT UNIQUE NOT NULL,
    display_name TEXT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT true,
    email_template_subject TEXT NOT NULL,
    email_template_body TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Tabela de configurações de notificação por usuário
CREATE TABLE IF NOT EXISTS public.notification_settings (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    user_id UUID NOT NULL, -- Sem FK para evitar quebrar o banco
    category_id UUID NOT NULL, -- Sem FK para evitar quebrar o banco
    is_enabled BOOLEAN DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(user_id, category_id)
);

-- 3. Tabela de logs de notificação
CREATE TABLE IF NOT EXISTS public.notification_logs (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    category_id UUID NOT NULL, -- Sem FK para evitar quebrar o banco
    user_id UUID NOT NULL, -- Sem FK para evitar quebrar o banco
    entity_type TEXT NOT NULL, -- 'mensagem' ou 'analise'
    entity_id UUID NOT NULL, -- ID da mensagem ou análise
    email_sent BOOLEAN DEFAULT false,
    email_error TEXT,
    sent_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Criar índices para performance
CREATE INDEX IF NOT EXISTS idx_notification_settings_user_id ON public.notification_settings(user_id);
CREATE INDEX IF NOT EXISTS idx_notification_settings_category_id ON public.notification_settings(category_id);
CREATE INDEX IF NOT EXISTS idx_notification_logs_created_at ON public.notification_logs(created_at);
CREATE INDEX IF NOT EXISTS idx_notification_logs_entity_type ON public.notification_logs(entity_type);
CREATE INDEX IF NOT EXISTS idx_notification_logs_email_sent ON public.notification_logs(email_sent);;
