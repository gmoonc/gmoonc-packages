-- PASSO 2: Criar funções de notificação no banco de dados

-- 1. Função para obter destinatários de notificação
CREATE OR REPLACE FUNCTION public.get_notification_recipients(p_category_name TEXT)
RETURNS TABLE(user_id UUID, email TEXT, name TEXT) AS $$
BEGIN
    RETURN QUERY
    SELECT
        ns.user_id,
        p.email,
        p.name
    FROM
        public.notification_settings ns
    JOIN
        public.notification_categories nc ON ns.category_id = nc.id
    JOIN
        public.profiles p ON ns.user_id = p.id
    WHERE
        nc.name = p_category_name 
        AND ns.is_enabled = TRUE 
        AND nc.is_active = TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Função para registrar um log de notificação
CREATE OR REPLACE FUNCTION public.log_notification(
    p_category_name TEXT,
    p_user_id UUID,
    p_entity_type TEXT,
    p_entity_id UUID,
    p_email_sent BOOLEAN DEFAULT FALSE,
    p_email_error TEXT DEFAULT NULL
)
RETURNS UUID AS $$
DECLARE
    log_id UUID;
    v_category_id UUID;
BEGIN
    SELECT id INTO v_category_id 
    FROM public.notification_categories 
    WHERE name = p_category_name;

    IF v_category_id IS NULL THEN
        RAISE EXCEPTION 'Category % not found', p_category_name;
    END IF;

    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    ) VALUES (
        v_category_id,
        p_user_id,
        p_entity_type,
        p_entity_id,
        p_email_sent,
        p_email_error,
        CASE WHEN p_email_sent THEN NOW() ELSE NULL END,
        NOW()
    )
    RETURNING id INTO log_id;

    RETURN log_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Função para enfileirar uma notificação (para processamento manual)
CREATE OR REPLACE FUNCTION public.queue_notification(
    p_category_name TEXT,
    p_entity_type TEXT,
    p_entity_id UUID
)
RETURNS UUID AS $$
DECLARE
    v_category_id UUID;
    log_id UUID;
    recipient_record RECORD;
BEGIN
    SELECT id INTO v_category_id 
    FROM public.notification_categories 
    WHERE name = p_category_name;

    IF v_category_id IS NULL THEN
        RAISE EXCEPTION 'Category % not found', p_category_name;
    END IF;

    -- Enfileirar para todos os usuários habilitados nesta categoria
    FOR recipient_record IN 
        SELECT user_id 
        FROM public.notification_settings 
        WHERE category_id = v_category_id 
        AND is_enabled = TRUE
    LOOP
        INSERT INTO public.notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            email_sent,
            email_error,
            sent_at,
            created_at
        ) VALUES (
            v_category_id,
            recipient_record.user_id,
            p_entity_type,
            p_entity_id,
            FALSE, -- Inicialmente não enviado
            NULL,
            NULL,
            NOW()
        )
        RETURNING id INTO log_id;
    END LOOP;

    RETURN log_id; -- Retorna o ID do último log enfileirado
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
