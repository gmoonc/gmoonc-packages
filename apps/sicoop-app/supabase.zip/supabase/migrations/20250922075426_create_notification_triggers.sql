-- Criar triggers para notificações automáticas
-- Estes triggers irão enfileirar notificações quando novas mensagens ou análises forem criadas

-- 1. Trigger para novas mensagens
CREATE OR REPLACE FUNCTION public.trigger_notify_new_message()
RETURNS TRIGGER AS $$
BEGIN
    -- Enfileirar notificação para a categoria de novas mensagens
    PERFORM public.queue_notification(
        'novas_mensagens',
        'mensagem',
        NEW.id
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Trigger para novas análises
CREATE OR REPLACE FUNCTION public.trigger_notify_new_analise()
RETURNS TRIGGER AS $$
BEGIN
    -- Enfileirar notificação para a categoria de novas análises
    PERFORM public.queue_notification(
        'novas_analises',
        'analise',
        NEW.id
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 3. Criar os triggers nas tabelas
DROP TRIGGER IF EXISTS notify_new_message ON public.mensagens;
CREATE TRIGGER notify_new_message
    AFTER INSERT ON public.mensagens
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_notify_new_message();

DROP TRIGGER IF EXISTS notify_new_analise ON public.analises_cobertura;
CREATE TRIGGER notify_new_analise
    AFTER INSERT ON public.analises_cobertura
    FOR EACH ROW
    EXECUTE FUNCTION public.trigger_notify_new_analise();;
