-- Função para processar notificações pendentes manualmente
CREATE OR REPLACE FUNCTION public.process_manual_notifications()
RETURNS TABLE(success BOOLEAN, message TEXT, recipient_count INTEGER) AS $$
DECLARE
    log_record RECORD;
    v_recipients JSONB;
    v_category_name TEXT;
    v_category_display_name TEXT;
    v_category_subject TEXT;
    v_category_body TEXT;
    v_entity_data JSONB;
    v_api_response JSONB;
    v_success_count INTEGER := 0;
    v_error_count INTEGER := 0;
    v_recipient_count INTEGER := 0;
BEGIN
    FOR log_record IN
        SELECT
            nl.id,
            nl.category_id,
            nl.user_id,
            nl.entity_type,
            nl.entity_id,
            nc.name AS category_name,
            nc.display_name AS category_display_name,
            nc.email_template_subject,
            nc.email_template_body
        FROM
            public.notification_logs nl
        JOIN
            public.notification_categories nc ON nl.category_id = nc.id
        WHERE
            nl.email_sent = FALSE
        ORDER BY nl.created_at ASC
    LOOP
        -- Obter dados da entidade (mensagem ou análise)
        IF log_record.entity_type = 'mensagem' THEN
            SELECT to_jsonb(m) INTO v_entity_data FROM public.mensagens m WHERE m.id = log_record.entity_id;
        ELSIF log_record.entity_type = 'analise' THEN
            SELECT to_jsonb(a) INTO v_entity_data FROM public.analises_cobertura a WHERE a.id = log_record.entity_id;
        END IF;

        IF v_entity_data IS NULL THEN
            -- Logar erro se a entidade não for encontrada
            PERFORM public.log_notification(
                log_record.category_name,
                log_record.user_id,
                log_record.entity_type,
                log_record.entity_id,
                FALSE,
                'Entidade não encontrada para o ID: ' || log_record.entity_id
            );
            v_error_count := v_error_count + 1;
            CONTINUE;
        END IF;

        -- Simular sucesso para teste (em produção, aqui chamaria a Edge Function)
        UPDATE public.notification_logs 
        SET 
            email_sent = TRUE,
            sent_at = NOW(),
            email_error = NULL
        WHERE id = log_record.id;
        
        v_success_count := v_success_count + 1;
        v_recipient_count := v_recipient_count + 1;
    END LOOP;

    RETURN QUERY SELECT TRUE, 'Notificações processadas com sucesso: ' || v_success_count || ' enviadas, ' || v_error_count || ' erros', v_recipient_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
