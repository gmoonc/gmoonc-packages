-- Adicionar foreign keys para as tabelas de notificação
-- Agora que limpamos os dados, podemos adicionar as relações

-- 1. Adicionar foreign key para notification_settings -> profiles
ALTER TABLE public.notification_settings 
ADD CONSTRAINT fk_notification_settings_user_id 
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

-- 2. Adicionar foreign key para notification_settings -> notification_categories
ALTER TABLE public.notification_settings 
ADD CONSTRAINT fk_notification_settings_category_id 
FOREIGN KEY (category_id) REFERENCES public.notification_categories(id) ON DELETE CASCADE;

-- 3. Adicionar foreign key para notification_logs -> notification_categories
ALTER TABLE public.notification_logs 
ADD CONSTRAINT fk_notification_logs_category_id 
FOREIGN KEY (category_id) REFERENCES public.notification_categories(id) ON DELETE CASCADE;

-- 4. Adicionar foreign key para notification_logs -> profiles
ALTER TABLE public.notification_logs 
ADD CONSTRAINT fk_notification_logs_user_id 
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;;
