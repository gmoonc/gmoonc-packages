-- Função para testar o envio de notificações com logs detalhados
CREATE OR REPLACE FUNCTION public.test_notification_sending(p_entity_id UUID)
RETURNS TABLE(success BOOLEAN, message TEXT, details JSONB) AS $$
DECLARE
    v_entity_data JSONB;
    v_category_data JSONB;
    v_user_data JSONB;
    v_template_subject TEXT;
    v_template_body TEXT;
    v_processed_subject TEXT;
    v_processed_body TEXT;
    v_result JSONB;
BEGIN
    -- Obter dados da entidade
    SELECT to_jsonb(a) INTO v_entity_data 
    FROM public.analises_cobertura a 
    WHERE a.id = p_entity_id;
    
    IF v_entity_data IS NULL THEN
        RETURN QUERY SELECT FALSE, 'Entidade não encontrada', to_jsonb('{"error": "Entity not found", "entity_id": "' || p_entity_id || '"}');
        RETURN;
    END IF;
    
    -- Obter dados da categoria
    SELECT to_jsonb(nc) INTO v_category_data
    FROM public.notification_categories nc
    WHERE nc.name = 'novas_analises';
    
    -- Obter dados do usuário
    SELECT to_jsonb(p) INTO v_user_data
    FROM public.profiles p
    WHERE p.role = 'administrador'
    LIMIT 1;
    
    -- Processar template
    v_template_subject := (v_category_data->>'email_template_subject');
    v_template_body := (v_category_data->>'email_template_body');
    
    -- Substituir variáveis no template
    v_processed_subject := v_template_subject;
    v_processed_body := v_template_body;
    
    -- Substituir variáveis específicas da análise
    v_processed_subject := replace(v_processed_subject, '{{nome_administrador}}', COALESCE(v_user_data->>'name', 'Administrador'));
    v_processed_subject := replace(v_processed_subject, '{{nome}}', COALESCE(v_entity_data->>'nome', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{email}}', COALESCE(v_entity_data->>'email', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{nome_fazenda}}', COALESCE(v_entity_data->>'nome_fazenda', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{area_fazenda_ha}}', COALESCE(v_entity_data->>'area_fazenda_ha', 'N/A'));
    
    v_processed_body := replace(v_processed_body, '{{nome_administrador}}', COALESCE(v_user_data->>'name', 'Administrador'));
    v_processed_body := replace(v_processed_body, '{{nome}}', COALESCE(v_entity_data->>'nome', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{email}}', COALESCE(v_entity_data->>'email', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{nome_fazenda}}', COALESCE(v_entity_data->>'nome_fazenda', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{area_fazenda_ha}}', COALESCE(v_entity_data->>'area_fazenda_ha', 'N/A'));
    
    -- Preparar resultado
    v_result := jsonb_build_object(
        'entity_data', v_entity_data,
        'category_data', v_category_data,
        'user_data', v_user_data,
        'processed_subject', v_processed_subject,
        'processed_body', v_processed_body,
        'template_variables', jsonb_build_object(
            'nome_administrador', COALESCE(v_user_data->>'name', 'Administrador'),
            'nome', COALESCE(v_entity_data->>'nome', 'N/A'),
            'email', COALESCE(v_entity_data->>'email', 'N/A'),
            'nome_fazenda', COALESCE(v_entity_data->>'nome_fazenda', 'N/A'),
            'area_fazenda_ha', COALESCE(v_entity_data->>'area_fazenda_ha', 'N/A')
        )
    );
    
    RETURN QUERY SELECT TRUE, 'Teste executado com sucesso', v_result;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
