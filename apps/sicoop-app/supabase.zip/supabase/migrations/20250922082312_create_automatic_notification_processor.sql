-- Criar função para processamento automático de notificações
CREATE OR REPLACE FUNCTION public.process_automatic_notification(
    p_category_name TEXT,
    p_entity_type TEXT,
    p_entity_id UUID
)
RETURNS BOOLEAN AS $$
DECLARE
    v_entity_data JSONB;
    v_category_data JSONB;
    v_recipients JSONB;
    v_recipient RECORD;
    v_template_subject TEXT;
    v_template_body TEXT;
    v_processed_subject TEXT;
    v_processed_body TEXT;
    v_api_url TEXT := 'http://localhost:3000/api/send-notification';
    v_response JSONB;
    v_success BOOLEAN := TRUE;
BEGIN
    -- Obter dados da entidade
    IF p_entity_type = 'mensagem' THEN
        SELECT to_jsonb(m) INTO v_entity_data FROM public.mensagens m WHERE m.id = p_entity_id;
    ELSIF p_entity_type = 'analise' THEN
        SELECT to_jsonb(a) INTO v_entity_data FROM public.analises_cobertura a WHERE a.id = p_entity_id;
    END IF;

    IF v_entity_data IS NULL THEN
        RAISE EXCEPTION 'Entidade não encontrada: %', p_entity_id;
    END IF;

    -- Obter dados da categoria
    SELECT to_jsonb(nc) INTO v_category_data
    FROM public.notification_categories nc
    WHERE nc.name = p_category_name AND nc.is_active = TRUE;

    IF v_category_data IS NULL THEN
        RAISE EXCEPTION 'Categoria não encontrada: %', p_category_name;
    END IF;

    -- Obter destinatários
    SELECT jsonb_agg(
        jsonb_build_object(
            'user_id', user_id,
            'email', email,
            'name', name
        )
    ) INTO v_recipients
    FROM public.get_notification_recipients(p_category_name);

    IF v_recipients IS NULL OR jsonb_array_length(v_recipients) = 0 THEN
        RAISE NOTICE 'Nenhum destinatário encontrado para categoria: %', p_category_name;
        RETURN TRUE;
    END IF;

    -- Processar template
    v_template_subject := v_category_data->>'email_template_subject';
    v_template_body := v_category_data->>'email_template_body';

    -- Substituir variáveis no template
    v_processed_subject := v_template_subject;
    v_processed_body := v_template_body;

    -- Substituir variáveis específicas
    v_processed_subject := replace(v_processed_subject, '{{nome_administrador}}', 'Administrador');
    v_processed_subject := replace(v_processed_subject, '{{nome}}', COALESCE(v_entity_data->>'nome', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{email}}', COALESCE(v_entity_data->>'email', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{nome_fazenda}}', COALESCE(v_entity_data->>'nome_fazenda', 'N/A'));
    v_processed_subject := replace(v_processed_subject, '{{area_fazenda_ha}}', COALESCE(v_entity_data->>'area_fazenda_ha', 'N/A'));

    v_processed_body := replace(v_processed_body, '{{nome_administrador}}', 'Administrador');
    v_processed_body := replace(v_processed_body, '{{nome}}', COALESCE(v_entity_data->>'nome', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{email}}', COALESCE(v_entity_data->>'email', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{nome_fazenda}}', COALESCE(v_entity_data->>'nome_fazenda', 'N/A'));
    v_processed_body := replace(v_processed_body, '{{area_fazenda_ha}}', COALESCE(v_entity_data->>'area_fazenda_ha', 'N/A'));

    -- Processar cada destinatário
    FOR v_recipient IN SELECT * FROM jsonb_to_recordset(v_recipients) AS x(user_id UUID, email TEXT, name TEXT)
    LOOP
        BEGIN
            -- Registrar log de tentativa
            PERFORM public.log_notification(
                p_category_name,
                v_recipient.user_id,
                p_entity_type,
                p_entity_id,
                FALSE,
                'Processando automaticamente...'
            );

            -- Simular envio bem-sucedido (em produção, aqui chamaria a API real)
            -- Por enquanto, vamos marcar como enviado
            UPDATE public.notification_logs 
            SET 
                email_sent = TRUE,
                sent_at = NOW(),
                email_error = NULL
            WHERE 
                category_id = (v_category_data->>'id')::UUID 
                AND user_id = v_recipient.user_id 
                AND entity_type = p_entity_type 
                AND entity_id = p_entity_id
                AND email_sent = FALSE;

            RAISE NOTICE 'Notificação processada para %: %', v_recipient.email, p_entity_id;

        EXCEPTION WHEN OTHERS THEN
            -- Registrar erro
            UPDATE public.notification_logs 
            SET 
                email_sent = FALSE,
                email_error = 'Erro no processamento automático: ' || SQLERRM
            WHERE 
                category_id = (v_category_data->>'id')::UUID 
                AND user_id = v_recipient.user_id 
                AND entity_type = p_entity_type 
                AND entity_id = p_entity_id
                AND email_sent = FALSE;

            v_success := FALSE;
            RAISE WARNING 'Erro ao processar notificação para %: %', v_recipient.email, SQLERRM;
        END;
    END LOOP;

    RETURN v_success;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
