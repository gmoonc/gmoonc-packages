-- Atualizar triggers para processamento automático
CREATE OR REPLACE FUNCTION public.trigger_notify_new_message()
RETURNS TRIGGER AS $$
BEGIN
    -- Enfileirar notificação para a categoria de novas mensagens
    PERFORM public.queue_notification(
        'novas_mensagens',
        'mensagem',
        NEW.id
    );
    
    -- Processar automaticamente
    PERFORM public.process_automatic_notification(
        'novas_mensagens',
        'mensagem',
        NEW.id
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION public.trigger_notify_new_analise()
RETURNS TRIGGER AS $$
BEGIN
    -- Enfileirar notificação para a categoria de novas análises
    PERFORM public.queue_notification(
        'novas_analises',
        'analise',
        NEW.id
    );
    
    -- Processar automaticamente
    PERFORM public.process_automatic_notification(
        'novas_analises',
        'analise',
        NEW.id
    );
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
