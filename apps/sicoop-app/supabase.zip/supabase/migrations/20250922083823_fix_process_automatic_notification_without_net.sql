-- Corrigir função de processamento automático sem usar extensão net
CREATE OR REPLACE FUNCTION public.process_automatic_notification(p_log_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_log_record RECORD;
    v_entity_data JSONB;
BEGIN
    -- Obter detalhes do log de notificação
    SELECT
        nl.id,
        nc.name AS category_name,
        nl.entity_type,
        nl.entity_id,
        p.email AS recipient_email,
        p.name AS recipient_name,
        nc.email_template_subject,
        nc.email_template_body
    INTO v_log_record
    FROM
        public.notification_logs nl
    JOIN
        public.notification_categories nc ON nl.category_id = nc.id
    JOIN
        public.profiles p ON nl.user_id = p.id
    WHERE
        nl.id = p_log_id;

    IF NOT FOUND THEN
        RAISE WARNING 'Log de notificação % não encontrado.', p_log_id;
        RETURN FALSE;
    END IF;

    -- Obter dados da entidade (mensagem ou análise)
    IF v_log_record.entity_type = 'mensagem' THEN
        SELECT to_jsonb(m) INTO v_entity_data FROM public.mensagens m WHERE m.id = v_log_record.entity_id;
    ELSIF v_log_record.entity_type = 'analise' THEN
        SELECT to_jsonb(a) INTO v_entity_data FROM public.analises_cobertura a WHERE a.id = v_log_record.entity_id;
    END IF;

    IF v_entity_data IS NULL THEN
        RAISE WARNING 'Dados da entidade % (tipo: %) não encontrados.', v_log_record.entity_id, v_log_record.entity_type;
        UPDATE public.notification_logs
        SET email_sent = FALSE, email_error = 'Dados da entidade não encontrados'
        WHERE id = p_log_id;
        RETURN FALSE;
    END IF;

    -- Por enquanto, apenas marcar como pendente para processamento manual
    -- Em produção, isso seria processado por um job ou Edge Function
    UPDATE public.notification_logs
    SET email_sent = FALSE, email_error = 'Aguardando processamento automático'
    WHERE id = p_log_id;
    
    RETURN TRUE;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
