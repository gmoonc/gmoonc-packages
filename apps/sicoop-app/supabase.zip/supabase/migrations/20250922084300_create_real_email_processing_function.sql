-- Criar função para processar notificações pendentes chamando a API real
CREATE OR REPLACE FUNCTION public.process_pending_notifications_real()
RETURNS TABLE(success BOOLEAN, message TEXT, processed_count INTEGER) AS $$
DECLARE
    log_record RECORD;
    v_processed_count INTEGER := 0;
    v_error_count INTEGER := 0;
    v_api_url TEXT;
    v_response_status INTEGER;
    v_response_body TEXT;
    v_entity_data JSONB;
BEGIN
    v_api_url := 'http://localhost:3000/api/send-notification';
    
    -- Processar notificações pendentes
    FOR log_record IN
        SELECT
            nl.id,
            nc.name AS category_name,
            nl.entity_type,
            nl.entity_id,
            p.email AS recipient_email,
            p.name AS recipient_name,
            nc.email_template_subject,
            nc.email_template_body
        FROM
            public.notification_logs nl
        JOIN
            public.notification_categories nc ON nl.category_id = nc.id
        JOIN
            public.profiles p ON nl.user_id = p.id
        WHERE
            nl.email_sent = FALSE
            AND (nl.email_error = 'Aguardando processamento automático' OR nl.email_error IS NULL)
        ORDER BY nl.created_at ASC
        LIMIT 5 -- Processar até 5 por vez
    LOOP
        -- Marcar como processando
        UPDATE public.notification_logs
        SET email_error = 'Processando...'
        WHERE id = log_record.id;
        
        -- Obter dados da entidade
        IF log_record.entity_type = 'mensagem' THEN
            SELECT to_jsonb(m) INTO v_entity_data FROM public.mensagens m WHERE m.id = log_record.entity_id;
        ELSIF log_record.entity_type = 'analise' THEN
            SELECT to_jsonb(a) INTO v_entity_data FROM public.analises_cobertura a WHERE a.id = log_record.entity_id;
        END IF;

        IF v_entity_data IS NULL THEN
            UPDATE public.notification_logs
            SET email_sent = FALSE, email_error = 'Dados da entidade não encontrados'
            WHERE id = log_record.id;
            v_error_count := v_error_count + 1;
            CONTINUE;
        END IF;

        -- Chamar a API usando net.http_post (se disponível) ou simular
        BEGIN
            -- Tentar chamar a API real
            SELECT
                status,
                content
            INTO
                v_response_status,
                v_response_body
            FROM
                net.http_post(
                    v_api_url,
                    'application/json',
                    jsonb_build_object(
                        'category', log_record.category_name,
                        'entityType', log_record.entity_type,
                        'entityId', log_record.entity_id,
                        'entityData', v_entity_data
                    )::TEXT,
                    ARRAY[]::net.http_header[]
                );

            IF v_response_status = 200 THEN
                UPDATE public.notification_logs
                SET email_sent = TRUE, sent_at = NOW(), email_error = NULL
                WHERE id = log_record.id;
                v_processed_count := v_processed_count + 1;
            ELSE
                UPDATE public.notification_logs
                SET email_sent = FALSE, email_error = 'Erro na API: ' || v_response_body
                WHERE id = log_record.id;
                v_error_count := v_error_count + 1;
            END IF;
        EXCEPTION
            WHEN OTHERS THEN
                -- Se a extensão net não estiver disponível, marcar como erro
                UPDATE public.notification_logs
                SET email_sent = FALSE, email_error = 'Extensão net não disponível: ' || SQLERRM
                WHERE id = log_record.id;
                v_error_count := v_error_count + 1;
        END;
    END LOOP;

    RETURN QUERY SELECT TRUE, 'Processadas: ' || v_processed_count || ' sucessos, ' || v_error_count || ' erros', v_processed_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
