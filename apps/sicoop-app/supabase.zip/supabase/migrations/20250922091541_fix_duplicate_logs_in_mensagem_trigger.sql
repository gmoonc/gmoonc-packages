-- Corrigir função de trigger para mensagens para evitar logs duplicados
CREATE OR REPLACE FUNCTION public.handle_new_mensagem_notification()
RETURNS TRIGGER AS $$
DECLARE
    v_log_id UUID;
    v_existing_logs INTEGER;
BEGIN
    -- Verificar se já existem logs para esta mensagem
    SELECT COUNT(*) INTO v_existing_logs
    FROM public.notification_logs
    WHERE entity_type = 'mensagem' AND entity_id = NEW.id;
    
    -- Se já existem logs, não criar novos
    IF v_existing_logs > 0 THEN
        RETURN NEW;
    END IF;

    -- Enfileirar a notificação apenas uma vez
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    )
    SELECT
        nc.id,
        ns.user_id,
        'mensagem',
        NEW.id,
        FALSE,
        'Aguardando processamento automático',
        NULL,
        NOW()
    FROM
        public.notification_categories nc
    JOIN
        public.notification_settings ns ON nc.id = ns.category_id
    WHERE
        nc.name = 'novas_mensagens' AND nc.is_active = TRUE AND ns.is_enabled = TRUE
    RETURNING id INTO v_log_id;

    -- Processar a notificação imediatamente
    IF v_log_id IS NOT NULL THEN
        PERFORM public.process_automatic_notification(v_log_id);
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
