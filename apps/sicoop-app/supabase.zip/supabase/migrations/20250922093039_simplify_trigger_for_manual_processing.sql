-- Simplificar trigger para apenas enfileirar notificações
CREATE OR REPLACE FUNCTION public.handle_new_analise_notification()
RETURNS TRIGGER AS $$
DECLARE
    v_log_id UUID;
BEGIN
    -- Enfileirar a notificação apenas uma vez usando ON CONFLICT
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    )
    SELECT
        nc.id,
        ns.user_id,
        'analise',
        NEW.id,
        FALSE,
        'Aguardando processamento automático',
        NULL,
        NOW()
    FROM
        public.notification_categories nc
    JOIN
        public.notification_settings ns ON nc.id = ns.category_id
    WHERE
        nc.name = 'novas_analises' AND nc.is_active = TRUE AND ns.is_enabled = TRUE
    ON CONFLICT (category_id, user_id, entity_type, entity_id) DO NOTHING
    RETURNING id INTO v_log_id;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
