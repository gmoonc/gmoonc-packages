-- Corrigir função de processamento automático para usar URL de produção
CREATE OR REPLACE FUNCTION public.process_automatic_notification(p_log_id UUID)
RETURNS BOOLEAN AS $$
DECLARE
    v_log_record RECORD;
    v_entity_data JSONB;
    v_success BOOLEAN := FALSE;
    v_api_url TEXT;
    v_response_status INTEGER;
    v_response_body TEXT;
    v_json_payload TEXT;
BEGIN
    -- Obter detalhes do log de notificação
    SELECT
        nl.id,
        nc.name AS category_name,
        nl.entity_type,
        nl.entity_id,
        p.email AS recipient_email,
        p.name AS recipient_name,
        nc.email_template_subject,
        nc.email_template_body
    INTO v_log_record
    FROM
        public.notification_logs nl
    JOIN
        public.notification_categories nc ON nl.category_id = nc.id
    JOIN
        public.profiles p ON nl.user_id = p.id
    WHERE
        nl.id = p_log_id;

    IF NOT FOUND THEN
        RAISE WARNING 'Log de notificação % não encontrado.', p_log_id;
        RETURN FALSE;
    END IF;

    -- Obter dados da entidade (mensagem ou análise)
    IF v_log_record.entity_type = 'mensagem' THEN
        SELECT to_jsonb(m) INTO v_entity_data FROM public.mensagens m WHERE m.id = v_log_record.entity_id;
    ELSIF v_log_record.entity_type = 'analise' THEN
        SELECT to_jsonb(a) INTO v_entity_data FROM public.analises_cobertura a WHERE a.id = v_log_record.entity_id;
    END IF;

    IF v_entity_data IS NULL THEN
        RAISE WARNING 'Dados da entidade % (tipo: %) não encontrados.', v_log_record.entity_id, v_log_record.entity_type;
        UPDATE public.notification_logs
        SET email_sent = FALSE, email_error = 'Dados da entidade não encontrados'
        WHERE id = p_log_id;
        RETURN FALSE;
    END IF;

    -- Marcar como processando
    UPDATE public.notification_logs
    SET email_error = 'Processando...'
    WHERE id = p_log_id;

    -- Usar URL de produção do Sicoop
    v_api_url := 'https://sicoop.goalmoon.com/api/send-notification';

    -- Construir payload JSON (mesmo formato que o botão usa)
    v_json_payload := jsonb_build_object(
        'category', v_log_record.category_name,
        'entityType', v_log_record.entity_type,
        'entityId', v_log_record.entity_id,
        'entityData', v_entity_data
    )::TEXT;

    -- Chamar a API Route do Next.js (mesmo método que o botão)
    BEGIN
        SELECT
            status,
            content
        INTO
            v_response_status,
            v_response_body
        FROM
            net.http_post(
                v_api_url,
                'application/json',
                v_json_payload,
                ARRAY[
                    ROW('Content-Type', 'application/json')::net.http_header
                ]
            );

        IF v_response_status = 200 THEN
            UPDATE public.notification_logs
            SET email_sent = TRUE, sent_at = NOW(), email_error = NULL
            WHERE id = p_log_id;
            v_success := TRUE;
            RAISE NOTICE 'Email enviado com sucesso via API para log %', p_log_id;
        ELSE
            RAISE WARNING 'Erro ao chamar API de notificação (status: %, corpo: %).', v_response_status, v_response_body;
            UPDATE public.notification_logs
            SET email_sent = FALSE, email_error = 'Erro na API: ' || v_response_body
            WHERE id = p_log_id;
            v_success := FALSE;
        END IF;

    EXCEPTION WHEN OTHERS THEN
        -- Se a extensão net não estiver disponível, marcar para processamento manual
        RAISE WARNING 'Extensão net não disponível, marcando para processamento manual: %', SQLERRM;
        UPDATE public.notification_logs
        SET email_sent = FALSE, email_error = 'Aguardando processamento automático'
        WHERE id = p_log_id;
        v_success := FALSE;
    END;
    
    RETURN v_success;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
