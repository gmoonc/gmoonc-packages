-- Modificar trigger para chamar Edge Function diretamente
CREATE OR REPLACE FUNCTION public.handle_new_analise_notification()
RETURNS TRIGGER AS $$
DECLARE
    v_log_id UUID;
    v_entity_data JSONB;
BEGIN
    -- Obter dados da entidade
    SELECT to_jsonb(NEW) INTO v_entity_data;

    -- Enfileirar a notificação apenas uma vez usando ON CONFLICT
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    )
    SELECT
        nc.id,
        ns.user_id,
        'analise',
        NEW.id,
        FALSE,
        'Aguardando processamento automático',
        NULL,
        NOW()
    FROM
        public.notification_categories nc
    JOIN
        public.notification_settings ns ON nc.id = ns.category_id
    WHERE
        nc.name = 'novas_analises' AND nc.is_active = TRUE AND ns.is_enabled = TRUE
    ON CONFLICT (category_id, user_id, entity_type, entity_id) DO NOTHING
    RETURNING id INTO v_log_id;

    -- Se criou um log, chamar a Edge Function para processar
    IF v_log_id IS NOT NULL THEN
        -- Chamar Edge Function para processar a notificação
        PERFORM net.http_post(
            'https://itrnlqdcbccyzqtymfju.supabase.co/functions/v1/send-notification-email',
            'application/json',
            jsonb_build_object(
                'category', 'novas_analises',
                'entityType', 'analise',
                'entityId', NEW.id,
                'entityData', v_entity_data
            )::TEXT,
            ARRAY[
                ROW('Authorization', 'Bearer ' || current_setting('app.service_role_key', true))::net.http_header
            ]
        );
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
