-- Criar função para processar mensagens da fila
CREATE OR REPLACE FUNCTION public.process_notification_queue()
RETURNS TABLE(processed_count INTEGER, error_count INTEGER) AS $$
DECLARE
    v_message RECORD;
    v_log_id UUID;
    v_category TEXT;
    v_entity_type TEXT;
    v_entity_id UUID;
    v_entity_data JSONB;
    v_processed_count INTEGER := 0;
    v_error_count INTEGER := 0;
    v_api_url TEXT;
    v_response_status INTEGER;
    v_response_body TEXT;
BEGIN
    -- Processar até 10 mensagens da fila
    FOR v_message IN 
        SELECT * FROM pgmq.read('notification_queue', 10, 30) -- 10 mensagens, timeout 30s
    LOOP
        BEGIN
            -- Extrair dados da mensagem
            v_log_id := (v_message.msg->>'log_id')::UUID;
            v_category := v_message.msg->>'category';
            v_entity_type := v_message.msg->>'entity_type';
            v_entity_id := (v_message.msg->>'entity_id')::UUID;
            v_entity_data := v_message.msg->'entity_data';

            -- Atualizar log para processando
            UPDATE public.notification_logs
            SET email_error = 'Processando via fila...'
            WHERE id = v_log_id;

            -- Chamar Edge Function para enviar email
            v_api_url := 'https://itrnlqdcbccyzqtymfju.supabase.co/functions/v1/send-notification-email';
            
            SELECT
                status,
                content
            INTO
                v_response_status,
                v_response_body
            FROM
                net.http_post(
                    v_api_url,
                    'application/json',
                    jsonb_build_object(
                        'category', v_category,
                        'entityType', v_entity_type,
                        'entityId', v_entity_id,
                        'entityData', v_entity_data
                    )::TEXT,
                    ARRAY[
                        ROW('Authorization', 'Bearer ' || current_setting('app.service_role_key', true))::net.http_header
                    ]
                );

            IF v_response_status = 200 THEN
                -- Marcar como enviado
                UPDATE public.notification_logs
                SET email_sent = TRUE, sent_at = NOW(), email_error = NULL
                WHERE id = v_log_id;
                
                -- Remover mensagem da fila
                PERFORM pgmq.delete('notification_queue', v_message.msg_id);
                v_processed_count := v_processed_count + 1;
            ELSE
                -- Marcar como erro
                UPDATE public.notification_logs
                SET email_sent = FALSE, email_error = 'Erro na API: ' || v_response_body
                WHERE id = v_log_id;
                
                -- Remover mensagem da fila mesmo com erro
                PERFORM pgmq.delete('notification_queue', v_message.msg_id);
                v_error_count := v_error_count + 1;
            END IF;

        EXCEPTION WHEN OTHERS THEN
            -- Marcar como erro e remover da fila
            UPDATE public.notification_logs
            SET email_sent = FALSE, email_error = 'Erro no processamento: ' || SQLERRM
            WHERE id = v_log_id;
            
            PERFORM pgmq.delete('notification_queue', v_message.msg_id);
            v_error_count := v_error_count + 1;
        END;
    END LOOP;

    RETURN QUERY SELECT v_processed_count, v_error_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
