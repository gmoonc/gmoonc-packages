-- Corrigir trigger para mensagens usando jsonb
CREATE OR REPLACE FUNCTION public.handle_new_mensagem_notification()
RETURNS TRIGGER AS $$
DECLARE
    v_log_id UUID;
    v_entity_data JSONB;
    v_message_id BIGINT;
BEGIN
    -- Obter dados da entidade
    SELECT to_jsonb(NEW) INTO v_entity_data;

    -- Enfileirar a notificação apenas uma vez usando ON CONFLICT
    INSERT INTO public.notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    )
    SELECT
        nc.id,
        ns.user_id,
        'mensagem',
        NEW.id,
        FALSE,
        'Enfileirado para processamento',
        NULL,
        NOW()
    FROM
        public.notification_categories nc
    JOIN
        public.notification_settings ns ON nc.id = ns.category_id
    WHERE
        nc.name = 'novas_mensagens' AND nc.is_active = TRUE AND ns.is_enabled = TRUE
    ON CONFLICT (category_id, user_id, entity_type, entity_id) DO NOTHING
    RETURNING id INTO v_log_id;

    -- Se criou um log, enviar mensagem para a fila
    IF v_log_id IS NOT NULL THEN
        -- Enviar mensagem para a fila (usando jsonb)
        SELECT pgmq.send(
            'notification_queue',
            jsonb_build_object(
                'log_id', v_log_id,
                'category', 'novas_mensagens',
                'entity_type', 'mensagem',
                'entity_id', NEW.id,
                'entity_data', v_entity_data
            ),
            0 -- delay = 0 (enviar imediatamente)
        ) INTO v_message_id;
        
        RAISE NOTICE 'Mensagem enviada para fila com ID: %', v_message_id;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
