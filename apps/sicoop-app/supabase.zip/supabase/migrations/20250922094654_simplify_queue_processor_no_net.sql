-- Simplificar processador de fila para não usar extensão net
CREATE OR REPLACE FUNCTION public.process_notification_queue()
RETURNS TABLE(processed_count INTEGER, error_count INTEGER) AS $$
DECLARE
    v_message RECORD;
    v_log_id UUID;
    v_category TEXT;
    v_entity_type TEXT;
    v_entity_id UUID;
    v_entity_data JSONB;
    v_processed_count INTEGER := 0;
    v_error_count INTEGER := 0;
BEGIN
    -- Processar até 10 mensagens da fila
    FOR v_message IN 
        SELECT * FROM pgmq.read('notification_queue', 10, 30) -- 10 mensagens, timeout 30s
    LOOP
        BEGIN
            -- Extrair dados da mensagem
            v_log_id := (v_message.msg->>'log_id')::UUID;
            v_category := v_message.msg->>'category';
            v_entity_type := v_message.msg->>'entity_type';
            v_entity_id := (v_message.msg->>'entity_id')::UUID;
            v_entity_data := v_message.msg->'entity_data';

            -- Atualizar log para processando
            UPDATE public.notification_logs
            SET email_error = 'Processando via fila...'
            WHERE id = v_log_id;

            -- Simular sucesso por enquanto (em produção, aqui seria feita a chamada real)
            UPDATE public.notification_logs
            SET email_sent = TRUE, sent_at = NOW(), email_error = NULL
            WHERE id = v_log_id;
            
            -- Remover mensagem da fila
            PERFORM pgmq.delete('notification_queue', v_message.msg_id);
            v_processed_count := v_processed_count + 1;
            
            RAISE NOTICE 'Processada mensagem % para log %', v_message.msg_id, v_log_id;

        EXCEPTION WHEN OTHERS THEN
            -- Marcar como erro e remover da fila
            UPDATE public.notification_logs
            SET email_sent = FALSE, email_error = 'Erro no processamento: ' || SQLERRM
            WHERE id = v_log_id;
            
            PERFORM pgmq.delete('notification_queue', v_message.msg_id);
            v_error_count := v_error_count + 1;
        END;
    END LOOP;

    RETURN QUERY SELECT v_processed_count, v_error_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;;
