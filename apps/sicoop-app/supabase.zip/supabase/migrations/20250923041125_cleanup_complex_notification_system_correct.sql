-- =====================================================
-- LIMPEZA COMPLETA DO SISTEMA COMPLEXO DE NOTIFICAÇÕES
-- =====================================================

-- 1. Remover triggers existentes
DROP TRIGGER IF EXISTS on_new_mensagem ON mensagens;
DROP TRIGGER IF EXISTS on_new_analise ON analises_cobertura;

-- 2. Remover funções relacionadas à fila e complexidade
DROP FUNCTION IF EXISTS process_notification_queue();
DROP FUNCTION IF EXISTS queue_notification(text, text, uuid);
DROP FUNCTION IF EXISTS process_automatic_notification(text, text, uuid);
DROP FUNCTION IF EXISTS handle_new_mensagem_notification();
DROP FUNCTION IF EXISTS handle_new_analise_notification();
DROP FUNCTION IF EXISTS process_manual_notifications();
DROP FUNCTION IF EXISTS test_notification_sending();
DROP FUNCTION IF EXISTS process_real_notifications();
DROP FUNCTION IF EXISTS process_pending_notifications_real();

-- 3. Criar função simples para chamar a API diretamente
CREATE OR REPLACE FUNCTION call_notification_api(
    p_category text,
    p_entity_type text,
    p_entity_id uuid
) RETURNS void AS $$
DECLARE
    api_url text;
    payload jsonb;
    response text;
BEGIN
    -- URL da API (usando a mesma que o botão usa)
    api_url := 'https://sicoop.goalmoon.com/api/send-notification';
    
    -- Montar payload igual ao botão
    payload := jsonb_build_object(
        'category', p_category,
        'entityType', p_entity_type,
        'entityId', p_entity_id::text,
        'entityData', jsonb_build_object(
            'nome', 'Sistema Automático',
            'email', 'sistema@sicoop.com',
            'nome_fazenda', 'Fazenda Automática',
            'area_fazenda_ha', '0.00'
        )
    );
    
    -- Fazer chamada HTTP usando a extensão http (se disponível)
    BEGIN
        -- Tentar usar http extension
        SELECT content INTO response
        FROM http((
            'POST',
            api_url,
            ARRAY[http_header('Content-Type', 'application/json')],
            'application/json',
            payload::text
        ));
        
        -- Log do sucesso
        INSERT INTO notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            status,
            message,
            created_at
        ) VALUES (
            (SELECT id FROM notification_categories WHERE name = p_category),
            (SELECT id FROM profiles WHERE email = 'sistema@sicoop.com' LIMIT 1),
            p_entity_type,
            p_entity_id,
            'enviado',
            'Notificação enviada via API: ' || response,
            NOW()
        );
        
    EXCEPTION WHEN OTHERS THEN
        -- Se http extension não estiver disponível, logar erro
        INSERT INTO notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            status,
            message,
            created_at
        ) VALUES (
            (SELECT id FROM notification_categories WHERE name = p_category),
            (SELECT id FROM profiles WHERE email = 'sistema@sicoop.com' LIMIT 1),
            p_entity_type,
            p_entity_id,
            'erro',
            'Erro ao chamar API: ' || SQLERRM,
            NOW()
        );
    END;
END;
$$ LANGUAGE plpgsql;;
