-- Corrigir função para usar estrutura correta da tabela
CREATE OR REPLACE FUNCTION call_notification_api(
    p_category text,
    p_entity_type text,
    p_entity_id uuid
) RETURNS void AS $$
DECLARE
    api_url text;
    payload jsonb;
    response text;
BEGIN
    -- URL da API (usando a mesma que o botão usa)
    api_url := 'https://sicoop.goalmoon.com/api/send-notification';
    
    -- Montar payload igual ao botão
    payload := jsonb_build_object(
        'category', p_category,
        'entityType', p_entity_type,
        'entityId', p_entity_id::text,
        'entityData', jsonb_build_object(
            'nome', 'Sistema Automático',
            'email', 'sistema@sicoop.com',
            'nome_fazenda', 'Fazenda Automática',
            'area_fazenda_ha', '0.00'
        )
    );
    
    -- Fazer chamada HTTP usando a extensão http (se disponível)
    BEGIN
        -- Tentar usar http extension
        SELECT content INTO response
        FROM http((
            'POST',
            api_url,
            ARRAY[http_header('Content-Type', 'application/json')],
            'application/json',
            payload::text
        ));
        
        -- Log do sucesso
        INSERT INTO notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            email_sent,
            email_error,
            sent_at,
            created_at
        ) VALUES (
            (SELECT id FROM notification_categories WHERE name = p_category),
            (SELECT id FROM profiles WHERE email = 'sistema@sicoop.com' LIMIT 1),
            p_entity_type,
            p_entity_id,
            true,
            null,
            NOW(),
            NOW()
        );
        
    EXCEPTION WHEN OTHERS THEN
        -- Se http extension não estiver disponível, logar erro
        INSERT INTO notification_logs (
            category_id,
            user_id,
            entity_type,
            entity_id,
            email_sent,
            email_error,
            sent_at,
            created_at
        ) VALUES (
            (SELECT id FROM notification_categories WHERE name = p_category),
            (SELECT id FROM profiles WHERE email = 'sistema@sicoop.com' LIMIT 1),
            p_entity_type,
            p_entity_id,
            false,
            'Erro ao chamar API: ' || SQLERRM,
            null,
            NOW()
        );
    END;
END;
$$ LANGUAGE plpgsql;;
