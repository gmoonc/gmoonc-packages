-- Criar função wrapper para análises
CREATE OR REPLACE FUNCTION notify_new_analise() RETURNS trigger AS $$
BEGIN
    PERFORM call_notification_api('novas_analises', 'analise', NEW.id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar função wrapper para mensagens
CREATE OR REPLACE FUNCTION notify_new_mensagem() RETURNS trigger AS $$
BEGIN
    PERFORM call_notification_api('novas_mensagens', 'mensagem', NEW.id);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;;
