-- Criar trigger para novas análises
CREATE TRIGGER on_new_analise
    AFTER INSERT ON analises_cobertura
    FOR EACH ROW
    EXECUTE FUNCTION notify_new_analise();

-- Criar trigger para novas mensagens
CREATE TRIGGER on_new_mensagem
    AFTER INSERT ON mensagens
    FOR EACH ROW
    EXECUTE FUNCTION notify_new_mensagem();;
