-- Corrigir políticas RLS para usar (select auth.uid()) em vez de auth.uid() diretamente
-- Isso resolve o problema "Database error granting user" durante recuperação de senha

-- Corrigir políticas da tabela profiles
DROP POLICY IF EXISTS "Users can view own profile" ON public.profiles;
CREATE POLICY "Users can view own profile" ON public.profiles
FOR SELECT USING ((select auth.uid()) = id);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles
FOR UPDATE USING ((select auth.uid()) = id);

DROP POLICY IF EXISTS "Admins can view all profiles" ON public.profiles;
CREATE POLICY "Admins can view all profiles" ON public.profiles
FOR SELECT USING (EXISTS (
  SELECT 1 FROM profiles profiles_1
  WHERE profiles_1.id = (select auth.uid()) AND profiles_1.role = 'administrador'
));

-- Corrigir políticas da tabela roles
DROP POLICY IF EXISTS "Admins can manage roles" ON public.roles;
CREATE POLICY "Admins can manage roles" ON public.roles
FOR ALL USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

-- Corrigir políticas da tabela modules
DROP POLICY IF EXISTS "Admins can manage modules" ON public.modules;
CREATE POLICY "Admins can manage modules" ON public.modules
FOR ALL USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

-- Corrigir políticas da tabela permissions
DROP POLICY IF EXISTS "Admins can manage permissions" ON public.permissions;
CREATE POLICY "Admins can manage permissions" ON public.permissions
FOR ALL USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

-- Corrigir políticas da tabela analises_cobertura
DROP POLICY IF EXISTS "Users can view own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can view own analyses" ON public.analises_cobertura
FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can update own analyses" ON public.analises_cobertura
FOR UPDATE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own analyses" ON public.analises_cobertura;
CREATE POLICY "Users can delete own analyses" ON public.analises_cobertura
FOR DELETE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Admins can view all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can view all analyses" ON public.analises_cobertura
FOR SELECT USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

DROP POLICY IF EXISTS "Admins can update all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can update all analyses" ON public.analises_cobertura
FOR UPDATE USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

DROP POLICY IF EXISTS "Admins can delete all analyses" ON public.analises_cobertura;
CREATE POLICY "Admins can delete all analyses" ON public.analises_cobertura
FOR DELETE USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

-- Corrigir políticas da tabela mensagens
DROP POLICY IF EXISTS "Users can view own messages" ON public.mensagens;
CREATE POLICY "Users can view own messages" ON public.mensagens
FOR SELECT USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can update own messages" ON public.mensagens;
CREATE POLICY "Users can update own messages" ON public.mensagens
FOR UPDATE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users can delete own messages" ON public.mensagens;
CREATE POLICY "Users can delete own messages" ON public.mensagens
FOR DELETE USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Admins can view all messages" ON public.mensagens;
CREATE POLICY "Admins can view all messages" ON public.mensagens
FOR SELECT USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

DROP POLICY IF EXISTS "Admins can update all messages" ON public.mensagens;
CREATE POLICY "Admins can update all messages" ON public.mensagens
FOR UPDATE USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));

DROP POLICY IF EXISTS "Admins can delete all messages" ON public.mensagens;
CREATE POLICY "Admins can delete all messages" ON public.mensagens
FOR DELETE USING (EXISTS (
  SELECT 1 FROM profiles
  WHERE profiles.id = (select auth.uid()) AND profiles.role = 'administrador'
));;
