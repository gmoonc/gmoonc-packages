-- Temporariamente desabilitar RLS na tabela profiles para resolver problema de recuperação de senha
-- Isso é uma medida temporária para diagnosticar o problema

-- Desabilitar RLS na tabela profiles temporariamente
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;

-- Permitir acesso completo para supabase_auth_admin
GRANT ALL ON public.profiles TO supabase_auth_admin;

-- Permitir acesso de leitura para anon (necessário durante recuperação)
GRANT SELECT ON public.profiles TO anon;;
