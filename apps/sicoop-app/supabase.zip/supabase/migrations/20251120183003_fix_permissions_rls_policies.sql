-- Migration: 20251120152924_fix_permissions_rls_policies.sql
-- Description: Corrigir políticas RLS da tabela permissions para permitir INSERT/UPDATE/DELETE por administradores
-- Date: 2025-11-20
-- 
-- PROBLEMA IDENTIFICADO:
-- A tabela permissions tinha apenas política de SELECT. As políticas de INSERT/UPDATE/DELETE
-- estavam usando auth.jwt() ->> 'role' que não funciona corretamente.
-- O sistema usa profiles.role = 'administrador' para verificar se um usuário é administrador.
--
-- SOLUÇÃO:
-- Remover política incorreta e criar políticas específicas para cada operação (INSERT, UPDATE, DELETE)
-- usando a verificação correta através da tabela profiles.
--
-- TABELAS AFETADAS:
-- - permissions (APENAS esta tabela)
--
-- TABELAS NÃO AFETADAS (mantidas intactas):
-- - mensagens (políticas permissivas mantidas para inserções anônimas do website)
-- - analises_cobertura (políticas permissivas mantidas para inserções anônimas do website)
-- - roles (não modificada)
-- - modules (não modificada)
-- - profiles (não modificada)

-- Remover política incorreta que usa auth.jwt() ->> 'role'
DROP POLICY IF EXISTS "Admin permissions management" ON public.permissions;

-- Manter política de SELECT existente (não modificar)
-- A política "Unified permissions access" já existe e permite SELECT para todos

-- Criar política de INSERT para administradores
-- Permite que usuários com role = 'administrador' na tabela profiles insiram permissões
CREATE POLICY "Admin permissions insert" ON public.permissions
    FOR INSERT 
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Criar política de UPDATE para administradores
-- Permite que usuários com role = 'administrador' na tabela profiles atualizem permissões
CREATE POLICY "Admin permissions update" ON public.permissions
    FOR UPDATE 
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    )
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Criar política de DELETE para administradores
-- Permite que usuários com role = 'administrador' na tabela profiles deletem permissões
CREATE POLICY "Admin permissions delete" ON public.permissions
    FOR DELETE 
    USING (
        EXISTS (
            SELECT 1 FROM public.profiles 
            WHERE id = auth.uid() AND role = 'administrador'
        )
    );

-- Comentários para documentação
COMMENT ON POLICY "Admin permissions insert" ON public.permissions IS 
    'Permite que administradores insiram novas permissões. Verifica profiles.role = administrador';

COMMENT ON POLICY "Admin permissions update" ON public.permissions IS 
    'Permite que administradores atualizem permissões existentes. Verifica profiles.role = administrador';

COMMENT ON POLICY "Admin permissions delete" ON public.permissions IS 
    'Permite que administradores deletem permissões. Verifica profiles.role = administrador';;
