-- Migration: Unificar status de análises e mensagens
-- Data: 2024-12-XX
-- Descrição: Padroniza os status entre analises_cobertura e mensagens para:
--            rascunho, pendente, em_analise, concluida, cancelada

-- 1. Remover constraints antigas
ALTER TABLE analises_cobertura DROP CONSTRAINT IF EXISTS analises_cobertura_status_check;
ALTER TABLE mensagens DROP CONSTRAINT IF EXISTS mensagens_status_check;

-- 2. Atualizar análises_cobertura: migrar 'solicitada' e 'enviada' para 'pendente'
UPDATE analises_cobertura 
SET status = 'pendente' 
WHERE status IN ('solicitada', 'enviada');

-- 3. Atualizar mensagens: migrar 'enviada' para 'pendente'
UPDATE mensagens 
SET status = 'pendente' 
WHERE status = 'enviada';

-- 4. Atualizar mensagens: migrar 'respondida' para 'concluida'
UPDATE mensagens 
SET status = 'concluida' 
WHERE status = 'respondida';

-- 5. Atualizar mensagens: migrar 'fechada' para 'cancelada'
UPDATE mensagens 
SET status = 'cancelada' 
WHERE status = 'fechada';

-- 6. Adicionar novas constraints com valores unificados
ALTER TABLE analises_cobertura 
ADD CONSTRAINT analises_cobertura_status_check 
CHECK (status IS NULL OR status IN ('rascunho', 'pendente', 'em_analise', 'concluida', 'cancelada'));

ALTER TABLE mensagens 
ADD CONSTRAINT mensagens_status_check 
CHECK (status IS NULL OR status IN ('rascunho', 'pendente', 'em_analise', 'concluida', 'cancelada'));

-- 7. Comentários para documentação
COMMENT ON COLUMN analises_cobertura.status IS 'Status da análise: rascunho, pendente, em_analise, concluida, cancelada';
COMMENT ON COLUMN mensagens.status IS 'Status da mensagem: rascunho, pendente, em_analise, concluida, cancelada';;
