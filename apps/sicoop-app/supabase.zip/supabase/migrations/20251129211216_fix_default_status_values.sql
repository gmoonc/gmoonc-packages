-- Migration: Corrigir valores DEFAULT de status
-- Data: 2024-12-XX
-- Descrição: Atualiza os valores DEFAULT de status para os novos valores unificados
--             Isso permite que inserções do website funcionem corretamente

-- 1. Atualizar DEFAULT de analises_cobertura de 'solicitada' para 'pendente'
ALTER TABLE analises_cobertura 
ALTER COLUMN status SET DEFAULT 'pendente';

-- 2. Atualizar DEFAULT de mensagens de 'enviada' para 'pendente'
ALTER TABLE mensagens 
ALTER COLUMN status SET DEFAULT 'pendente';

-- 3. Comentários para documentação
COMMENT ON COLUMN analises_cobertura.status IS 'Status da análise: rascunho, pendente, em_analise, concluida, cancelada. DEFAULT: pendente';
COMMENT ON COLUMN mensagens.status IS 'Status da mensagem: rascunho, pendente, em_analise, concluida, cancelada. DEFAULT: pendente';;
