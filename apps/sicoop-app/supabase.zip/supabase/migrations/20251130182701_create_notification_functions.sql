-- Função para buscar destinatários de uma categoria
CREATE OR REPLACE FUNCTION get_notification_recipients(
    p_category_name TEXT
)
RETURNS TABLE (
    user_id UUID,
    email TEXT,
    name TEXT
) 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
    RETURN QUERY
    SELECT DISTINCT
        p.id AS user_id,
        p.email,
        p.name
    FROM notification_settings ns
    INNER JOIN notification_categories nc ON nc.id = ns.category_id
    INNER JOIN profiles p ON p.id = ns.user_id
    WHERE nc.name = p_category_name
    AND nc.is_active = true
    AND ns.is_enabled = true;
END;
$$;

-- Função para registrar log de notificação
CREATE OR REPLACE FUNCTION log_notification(
    p_category_name TEXT,
    p_user_id UUID,
    p_entity_type TEXT,
    p_entity_id TEXT,
    p_email_sent BOOLEAN DEFAULT false,
    p_email_error TEXT DEFAULT NULL
)
RETURNS UUID 
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_category_id UUID;
    v_log_id UUID;
BEGIN
    -- Buscar categoria
    SELECT id INTO v_category_id
    FROM notification_categories
    WHERE name = p_category_name
    AND is_active = true
    LIMIT 1;

    IF v_category_id IS NULL THEN
        RAISE EXCEPTION 'Categoria % não encontrada ou inativa', p_category_name;
    END IF;

    -- Criar ou atualizar log
    INSERT INTO notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    ) VALUES (
        v_category_id,
        p_user_id,
        p_entity_type,
        p_entity_id::UUID,
        p_email_sent,
        p_email_error,
        CASE WHEN p_email_sent THEN NOW() ELSE NULL END,
        NOW()
    )
    ON CONFLICT DO NOTHING
    RETURNING id INTO v_log_id;

    -- Se não inseriu (conflito), buscar o existente e atualizar
    IF v_log_id IS NULL THEN
        SELECT id INTO v_log_id
        FROM notification_logs
        WHERE category_id = v_category_id
        AND user_id = p_user_id
        AND entity_type = p_entity_type
        AND entity_id = p_entity_id::UUID
        ORDER BY created_at DESC
        LIMIT 1;

        -- Atualizar se encontrou
        IF v_log_id IS NOT NULL THEN
            UPDATE notification_logs
            SET 
                email_sent = p_email_sent,
                email_error = p_email_error,
                sent_at = CASE WHEN p_email_sent THEN NOW() ELSE sent_at END
            WHERE id = v_log_id;
        END IF;
    END IF;

    RETURN v_log_id;
END;
$$;;
