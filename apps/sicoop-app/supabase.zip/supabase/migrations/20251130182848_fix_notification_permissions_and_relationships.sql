-- Remover políticas antigas e criar novas mais permissivas para administradores
DROP POLICY IF EXISTS "Allow authenticated users to manage notification_categories" ON public.notification_categories;
DROP POLICY IF EXISTS "Allow authenticated users to manage notification_settings" ON public.notification_settings;
DROP POLICY IF EXISTS "Allow authenticated users to manage notification_logs" ON public.notification_logs;

-- Políticas para notification_categories (permitir tudo para administradores)
CREATE POLICY "Administrators can manage notification_categories"
ON public.notification_categories
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Políticas para notification_settings
CREATE POLICY "Administrators can manage notification_settings"
ON public.notification_settings
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Políticas para notification_logs (permitir leitura e inserção para administradores)
CREATE POLICY "Administrators can manage notification_logs"
ON public.notification_logs
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Adicionar foreign keys para permitir joins automáticos do Supabase
-- Primeiro, remover constraints se existirem
ALTER TABLE public.notification_settings 
DROP CONSTRAINT IF EXISTS notification_settings_user_id_fkey;

ALTER TABLE public.notification_settings 
DROP CONSTRAINT IF EXISTS notification_settings_category_id_fkey;

ALTER TABLE public.notification_logs 
DROP CONSTRAINT IF EXISTS notification_logs_user_id_fkey;

ALTER TABLE public.notification_logs 
DROP CONSTRAINT IF EXISTS notification_logs_category_id_fkey;

-- Criar foreign keys
ALTER TABLE public.notification_settings
ADD CONSTRAINT notification_settings_user_id_fkey
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.notification_settings
ADD CONSTRAINT notification_settings_category_id_fkey
FOREIGN KEY (category_id) REFERENCES public.notification_categories(id) ON DELETE CASCADE;

ALTER TABLE public.notification_logs
ADD CONSTRAINT notification_logs_user_id_fkey
FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;

ALTER TABLE public.notification_logs
ADD CONSTRAINT notification_logs_category_id_fkey
FOREIGN KEY (category_id) REFERENCES public.notification_categories(id) ON DELETE CASCADE;;
