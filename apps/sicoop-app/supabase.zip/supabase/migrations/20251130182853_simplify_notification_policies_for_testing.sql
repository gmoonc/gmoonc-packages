-- Remover políticas anteriores
DROP POLICY IF EXISTS "Administrators can manage notification_categories" ON public.notification_categories;
DROP POLICY IF EXISTS "Administrators can manage notification_settings" ON public.notification_settings;
DROP POLICY IF EXISTS "Administrators can manage notification_logs" ON public.notification_logs;

-- Políticas simplificadas para permitir acesso completo a usuários autenticados (temporário para testes)
CREATE POLICY "Authenticated users can access notification_categories"
ON public.notification_categories
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Authenticated users can access notification_settings"
ON public.notification_settings
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "Authenticated users can access notification_logs"
ON public.notification_logs
FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);;
