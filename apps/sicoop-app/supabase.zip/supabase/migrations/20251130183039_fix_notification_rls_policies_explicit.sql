-- Remover todas as políticas existentes
DROP POLICY IF EXISTS "Authenticated users can access notification_categories" ON public.notification_categories;
DROP POLICY IF EXISTS "Authenticated users can access notification_settings" ON public.notification_settings;
DROP POLICY IF EXISTS "Authenticated users can access notification_logs" ON public.notification_logs;

-- Recriar políticas de forma mais explícita
-- Para notification_categories
CREATE POLICY "notification_categories_select_policy"
ON public.notification_categories
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "notification_categories_insert_policy"
ON public.notification_categories
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "notification_categories_update_policy"
ON public.notification_categories
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "notification_categories_delete_policy"
ON public.notification_categories
FOR DELETE
TO authenticated
USING (true);

-- Para notification_settings
CREATE POLICY "notification_settings_select_policy"
ON public.notification_settings
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "notification_settings_insert_policy"
ON public.notification_settings
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "notification_settings_update_policy"
ON public.notification_settings
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "notification_settings_delete_policy"
ON public.notification_settings
FOR DELETE
TO authenticated
USING (true);

-- Para notification_logs
CREATE POLICY "notification_logs_select_policy"
ON public.notification_logs
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "notification_logs_insert_policy"
ON public.notification_logs
FOR INSERT
TO authenticated
WITH CHECK (true);

CREATE POLICY "notification_logs_update_policy"
ON public.notification_logs
FOR UPDATE
TO authenticated
USING (true)
WITH CHECK (true);

CREATE POLICY "notification_logs_delete_policy"
ON public.notification_logs
FOR DELETE
TO authenticated
USING (true);;
