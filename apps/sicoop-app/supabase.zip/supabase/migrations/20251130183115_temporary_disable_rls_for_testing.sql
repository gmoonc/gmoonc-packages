-- TEMPORÁRIO: Desabilitar RLS para testes (apenas para debug)
-- ATENÇÃO: Isso deve ser revertido depois dos testes!

-- Desabilitar RLS temporariamente
ALTER TABLE public.notification_categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_logs DISABLE ROW LEVEL SECURITY;;
