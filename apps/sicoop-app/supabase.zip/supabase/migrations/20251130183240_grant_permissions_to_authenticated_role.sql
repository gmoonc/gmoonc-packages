-- Garantir que o role authenticated tem permissões explícitas
GRANT ALL ON public.notification_categories TO authenticated;
GRANT ALL ON public.notification_settings TO authenticated;
GRANT ALL ON public.notification_logs TO authenticated;

-- Garantir que o role anon também tem permissões (caso necessário)
GRANT ALL ON public.notification_categories TO anon;
GRANT ALL ON public.notification_settings TO anon;
GRANT ALL ON public.notification_logs TO anon;

-- Verificar se RLS está realmente desabilitado (forçar novamente)
ALTER TABLE public.notification_categories DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_logs DISABLE ROW LEVEL SECURITY;;
