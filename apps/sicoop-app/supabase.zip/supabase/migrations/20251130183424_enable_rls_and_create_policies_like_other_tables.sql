-- Reabilitar RLS (como nas outras tabelas)
ALTER TABLE public.notification_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notification_logs ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas se existirem
DROP POLICY IF EXISTS "notification_categories_select_policy" ON public.notification_categories;
DROP POLICY IF EXISTS "notification_categories_insert_policy" ON public.notification_categories;
DROP POLICY IF EXISTS "notification_categories_update_policy" ON public.notification_categories;
DROP POLICY IF EXISTS "notification_categories_delete_policy" ON public.notification_categories;
DROP POLICY IF EXISTS "notification_settings_select_policy" ON public.notification_settings;
DROP POLICY IF EXISTS "notification_settings_insert_policy" ON public.notification_settings;
DROP POLICY IF EXISTS "notification_settings_update_policy" ON public.notification_settings;
DROP POLICY IF EXISTS "notification_settings_delete_policy" ON public.notification_settings;
DROP POLICY IF EXISTS "notification_logs_select_policy" ON public.notification_logs;
DROP POLICY IF EXISTS "notification_logs_insert_policy" ON public.notification_logs;
DROP POLICY IF EXISTS "notification_logs_update_policy" ON public.notification_logs;
DROP POLICY IF EXISTS "notification_logs_delete_policy" ON public.notification_logs;

-- Criar políticas similares às outras tabelas (especialmente permissions que é administrativo)
-- Para notification_categories: apenas administradores podem gerenciar
CREATE POLICY "Admin notification_categories select"
ON public.notification_categories
FOR SELECT
TO public
USING (true);

CREATE POLICY "Admin notification_categories insert"
ON public.notification_categories
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_categories update"
ON public.notification_categories
FOR UPDATE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_categories delete"
ON public.notification_categories
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Para notification_settings: usuários autenticados podem ver suas próprias configurações, admins podem tudo
CREATE POLICY "Notification_settings select"
ON public.notification_settings
FOR SELECT
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings insert"
ON public.notification_settings
FOR INSERT
TO public
WITH CHECK (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings update"
ON public.notification_settings
FOR UPDATE
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings delete"
ON public.notification_settings
FOR DELETE
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Para notification_logs: apenas administradores podem ver logs
CREATE POLICY "Admin notification_logs select"
ON public.notification_logs
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_logs insert"
ON public.notification_logs
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Admin notification_logs update"
ON public.notification_logs
FOR UPDATE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_logs delete"
ON public.notification_logs
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);;
