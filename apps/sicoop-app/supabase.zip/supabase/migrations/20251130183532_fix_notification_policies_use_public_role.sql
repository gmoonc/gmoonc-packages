-- Remover políticas antigas
DROP POLICY IF EXISTS "Admin notification_categories select" ON public.notification_categories;
DROP POLICY IF EXISTS "Admin notification_categories insert" ON public.notification_categories;
DROP POLICY IF EXISTS "Admin notification_categories update" ON public.notification_categories;
DROP POLICY IF EXISTS "Admin notification_categories delete" ON public.notification_categories;
DROP POLICY IF EXISTS "Notification_settings select" ON public.notification_settings;
DROP POLICY IF EXISTS "Notification_settings insert" ON public.notification_settings;
DROP POLICY IF EXISTS "Notification_settings update" ON public.notification_settings;
DROP POLICY IF EXISTS "Notification_settings delete" ON public.notification_settings;
DROP POLICY IF EXISTS "Admin notification_logs select" ON public.notification_logs;
DROP POLICY IF EXISTS "Notification_logs insert" ON public.notification_logs;
DROP POLICY IF EXISTS "Admin notification_logs update" ON public.notification_logs;
DROP POLICY IF EXISTS "Admin notification_logs delete" ON public.notification_logs;

-- Criar políticas EXATAMENTE como permissions (usando TO public)
-- Para notification_categories
CREATE POLICY "Unified notification_categories access"
ON public.notification_categories
FOR SELECT
TO public
USING (true);

CREATE POLICY "Admin notification_categories insert"
ON public.notification_categories
FOR INSERT
TO public
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_categories update"
ON public.notification_categories
FOR UPDATE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_categories delete"
ON public.notification_categories
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Para notification_settings (similar ao padrão de outras tabelas)
CREATE POLICY "Notification_settings select"
ON public.notification_settings
FOR SELECT
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings insert"
ON public.notification_settings
FOR INSERT
TO public
WITH CHECK (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings update"
ON public.notification_settings
FOR UPDATE
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_settings delete"
ON public.notification_settings
FOR DELETE
TO public
USING (
  user_id = auth.uid() OR
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

-- Para notification_logs
CREATE POLICY "Admin notification_logs select"
ON public.notification_logs
FOR SELECT
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Notification_logs insert"
ON public.notification_logs
FOR INSERT
TO public
WITH CHECK (true);

CREATE POLICY "Admin notification_logs update"
ON public.notification_logs
FOR UPDATE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);

CREATE POLICY "Admin notification_logs delete"
ON public.notification_logs
FOR DELETE
TO public
USING (
  EXISTS (
    SELECT 1 FROM profiles 
    WHERE profiles.id = auth.uid() 
    AND profiles.role = 'administrador'
  )
);;
