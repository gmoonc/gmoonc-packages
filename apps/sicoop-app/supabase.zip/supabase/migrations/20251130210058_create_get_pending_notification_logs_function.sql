-- Criar função RPC para buscar logs pendentes com SECURITY DEFINER para bypass RLS
CREATE OR REPLACE FUNCTION get_pending_notification_logs(
  p_limit INTEGER DEFAULT 10
)
RETURNS TABLE (
  id UUID,
  category_id UUID,
  user_id UUID,
  entity_type TEXT,
  entity_id UUID,
  email_sent BOOLEAN,
  email_error TEXT,
  created_at TIMESTAMPTZ,
  sent_at TIMESTAMPTZ,
  category_name TEXT,
  category_display_name TEXT,
  category_email_template_subject TEXT,
  category_email_template_body TEXT,
  user_name TEXT,
  user_email TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    nl.id,
    nl.category_id,
    nl.user_id,
    nl.entity_type,
    nl.entity_id,
    nl.email_sent,
    nl.email_error,
    nl.created_at,
    nl.sent_at,
    nc.name as category_name,
    nc.display_name as category_display_name,
    nc.email_template_subject as category_email_template_subject,
    nc.email_template_body as category_email_template_body,
    p.name as user_name,
    p.email as user_email
  FROM notification_logs nl
  INNER JOIN notification_categories nc ON nl.category_id = nc.id
  INNER JOIN profiles p ON nl.user_id = p.id
  WHERE nl.email_sent = false
    AND (nl.email_error IS NULL OR nl.email_error = 'Aguardando processamento automático')
  ORDER BY nl.created_at ASC
  LIMIT p_limit;
END;
$$;;
