-- Criar função RPC com SECURITY DEFINER para atualizar logs de notificação
-- Isso bypassa RLS e permite que a API atualize os logs mesmo sem auth.uid()

CREATE OR REPLACE FUNCTION update_notification_log(
  p_log_id UUID,
  p_email_sent BOOLEAN DEFAULT NULL,
  p_email_error TEXT DEFAULT NULL,
  p_sent_at TIMESTAMPTZ DEFAULT NULL
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE notification_logs
  SET 
    email_sent = COALESCE(p_email_sent, email_sent),
    email_error = COALESCE(p_email_error, email_error),
    sent_at = COALESCE(p_sent_at, sent_at)
  WHERE id = p_log_id;
END;
$$;

-- Comentário explicativo
COMMENT ON FUNCTION update_notification_log IS 'Atualiza um log de notificação. Usa SECURITY DEFINER para bypass RLS.';;
