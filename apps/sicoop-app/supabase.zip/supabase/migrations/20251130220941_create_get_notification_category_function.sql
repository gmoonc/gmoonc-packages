-- Criar função RPC com SECURITY DEFINER para buscar categoria de notificação
-- Isso bypassa RLS e permite que a API busque categorias mesmo sem auth.uid()

CREATE OR REPLACE FUNCTION get_notification_category(
  p_category_name TEXT DEFAULT NULL,
  p_search_term TEXT DEFAULT NULL
)
RETURNS TABLE (
  id UUID,
  name TEXT,
  display_name TEXT,
  description TEXT,
  is_active BOOLEAN,
  email_template_subject TEXT,
  email_template_body TEXT
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF p_category_name IS NOT NULL THEN
    -- Buscar por nome exato
    RETURN QUERY
    SELECT 
      nc.id,
      nc.name,
      nc.display_name,
      nc.description,
      nc.is_active,
      nc.email_template_subject,
      nc.email_template_body
    FROM notification_categories nc
    WHERE nc.name = p_category_name
    AND nc.is_active = true
    LIMIT 1;
  ELSIF p_search_term IS NOT NULL THEN
    -- Buscar por termo de busca (name ou display_name)
    RETURN QUERY
    SELECT 
      nc.id,
      nc.name,
      nc.display_name,
      nc.description,
      nc.is_active,
      nc.email_template_subject,
      nc.email_template_body
    FROM notification_categories nc
    WHERE nc.is_active = true
    AND (
      LOWER(nc.name) LIKE '%' || LOWER(p_search_term) || '%' OR
      LOWER(nc.display_name) LIKE '%' || LOWER(p_search_term) || '%'
    )
    ORDER BY 
      CASE WHEN LOWER(nc.name) = LOWER(p_search_term) THEN 1 ELSE 2 END,
      nc.display_name
    LIMIT 1;
  ELSE
    -- Retornar todas as categorias ativas
    RETURN QUERY
    SELECT 
      nc.id,
      nc.name,
      nc.display_name,
      nc.description,
      nc.is_active,
      nc.email_template_subject,
      nc.email_template_body
    FROM notification_categories nc
    WHERE nc.is_active = true
    ORDER BY nc.display_name;
  END IF;
END;
$$;

-- Comentário explicativo
COMMENT ON FUNCTION get_notification_category IS 'Busca categoria(s) de notificação. Usa SECURITY DEFINER para bypass RLS.';;
