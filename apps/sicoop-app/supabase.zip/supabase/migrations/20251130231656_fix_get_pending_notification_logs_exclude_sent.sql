-- Corrigir função get_pending_notification_logs para excluir logs de entidades já notificadas com sucesso
CREATE OR REPLACE FUNCTION public.get_pending_notification_logs(p_limit integer DEFAULT 10)
RETURNS TABLE(
    id uuid, 
    category_id uuid, 
    user_id uuid, 
    entity_type text, 
    entity_id uuid, 
    email_sent boolean, 
    email_error text, 
    created_at timestamp with time zone, 
    sent_at timestamp with time zone, 
    category_name text, 
    category_display_name text, 
    category_email_template_subject text, 
    category_email_template_body text, 
    user_name text, 
    user_email text
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    nl.id,
    nl.category_id,
    nl.user_id,
    nl.entity_type,
    nl.entity_id,
    nl.email_sent,
    nl.email_error,
    nl.created_at,
    nl.sent_at,
    nc.name as category_name,
    nc.display_name as category_display_name,
    nc.email_template_subject as category_email_template_subject,
    nc.email_template_body as category_email_template_body,
    p.name as user_name,
    p.email as user_email
  FROM notification_logs nl
  INNER JOIN notification_categories nc ON nl.category_id = nc.id
  INNER JOIN profiles p ON nl.user_id = p.id
  WHERE nl.email_sent = false
    AND (nl.email_error IS NULL OR nl.email_error = 'Aguardando processamento automático')
    -- EXCLUIR logs onde já existe um log com email_sent=true para a mesma combinação entity_id+user_id
    AND NOT EXISTS (
      SELECT 1 
      FROM notification_logs nl2 
      WHERE nl2.entity_id = nl.entity_id 
        AND nl2.user_id = nl.user_id 
        AND nl2.entity_type = nl.entity_type
        AND nl2.email_sent = true
    )
  ORDER BY nl.created_at ASC
  LIMIT p_limit;
END;
$$;
;
