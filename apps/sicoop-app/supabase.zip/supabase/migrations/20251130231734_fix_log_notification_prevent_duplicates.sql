-- Corrigir função log_notification para não criar logs se já existe um com email_sent=true
CREATE OR REPLACE FUNCTION public.log_notification(
    p_category_name text, 
    p_user_id uuid, 
    p_entity_type text, 
    p_entity_id text, 
    p_email_sent boolean DEFAULT false, 
    p_email_error text DEFAULT NULL
)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
    v_category_id UUID;
    v_log_id UUID;
    v_existing_sent_log_id UUID;
BEGIN
    -- Buscar categoria
    SELECT id INTO v_category_id
    FROM notification_categories
    WHERE name = p_category_name
    AND is_active = true
    LIMIT 1;

    IF v_category_id IS NULL THEN
        RAISE EXCEPTION 'Categoria % não encontrada ou inativa', p_category_name;
    END IF;

    -- Verificar se já existe um log com email_sent=true para esta combinação
    -- Se existir, não criar novo log e retornar o existente
    SELECT id INTO v_existing_sent_log_id
    FROM notification_logs
    WHERE category_id = v_category_id
      AND user_id = p_user_id
      AND entity_type = p_entity_type
      AND entity_id = p_entity_id::UUID
      AND email_sent = true
    ORDER BY created_at DESC
    LIMIT 1;

    -- Se já existe um log com email_sent=true, retornar esse ID sem criar novo
    IF v_existing_sent_log_id IS NOT NULL THEN
        RETURN v_existing_sent_log_id;
    END IF;

    -- Buscar log existente (mesmo que com email_sent=false) para atualizar
    SELECT id INTO v_log_id
    FROM notification_logs
    WHERE category_id = v_category_id
      AND user_id = p_user_id
      AND entity_type = p_entity_type
      AND entity_id = p_entity_id::UUID
    ORDER BY created_at DESC
    LIMIT 1;

    -- Se encontrou log existente, atualizar
    IF v_log_id IS NOT NULL THEN
        UPDATE notification_logs
        SET 
            email_sent = p_email_sent,
            email_error = p_email_error,
            sent_at = CASE WHEN p_email_sent THEN NOW() ELSE sent_at END
        WHERE id = v_log_id;
        
        RETURN v_log_id;
    END IF;

    -- Se não encontrou log existente, criar novo
    INSERT INTO notification_logs (
        category_id,
        user_id,
        entity_type,
        entity_id,
        email_sent,
        email_error,
        sent_at,
        created_at
    ) VALUES (
        v_category_id,
        p_user_id,
        p_entity_type,
        p_entity_id::UUID,
        p_email_sent,
        p_email_error,
        CASE WHEN p_email_sent THEN NOW() ELSE NULL END,
        NOW()
    )
    RETURNING id INTO v_log_id;

    RETURN v_log_id;
END;
$$;
;
