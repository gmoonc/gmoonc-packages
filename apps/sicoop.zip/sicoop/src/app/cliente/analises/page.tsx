import AnalisesManager from '@/components/AnalisesManager';

export default function AnalisesClientePage() {
  return <AnalisesManager />;
}
