import MensagensManager from '@/components/MensagensManager';

export default function MensagensClientePage() {
  return <MensagensManager />;
}
