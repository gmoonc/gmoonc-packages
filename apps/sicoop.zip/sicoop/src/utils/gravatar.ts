// Backwards compatibility layer for legacy imports.
// New code should import from '@/lib/gravatar'.
export { getGravatarHash, fetchGravatarAvatarByEmail } from '@/lib/gravatar';
